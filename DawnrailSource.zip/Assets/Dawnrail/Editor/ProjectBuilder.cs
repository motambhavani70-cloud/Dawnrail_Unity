using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Dawnrail.Editor
{
    [InitializeOnLoad]
    public static class ProjectBuilder
    {
        const string Scene="Assets/Dawnrail/Scenes/Dawnrail.unity";
        static ProjectBuilder() { EditorApplication.delayCall+=()=> { if(!Application.isBatchMode&&!File.Exists("Assets/Dawnrail/Resources/Quality/2.asset"))Prepare(); }; }
        static void Set(SerializedObject obj,string name,int value) { var p=obj.FindProperty(name);if(p==null)throw new InvalidOperationException("Missing Unity property: "+name);p.intValue=value; }
        static void Set(SerializedObject obj,string name,bool value) { var p=obj.FindProperty(name);if(p==null)throw new InvalidOperationException("Missing Unity property: "+name);p.boolValue=value; }
        [MenuItem("Dawnrail/Prepare project")]
        public static void Prepare()
        {
            Directory.CreateDirectory("Assets/Dawnrail/Resources/Quality");AssetDatabase.Refresh();
            var renderer=AssetDatabase.LoadAssetAtPath<UniversalRendererData>("Assets/Dawnrail/Resources/Quality/Renderer.asset");
            if(renderer==null) { renderer=ScriptableObject.CreateInstance<UniversalRendererData>();renderer.name="Dawnrail Forward Renderer";renderer.renderingMode=RenderingMode.Forward;renderer.postProcessData=AssetDatabase.LoadAssetAtPath<PostProcessData>("Packages/com.unity.render-pipelines.universal/Runtime/Data/PostProcessData.asset");AssetDatabase.CreateAsset(renderer,"Assets/Dawnrail/Resources/Quality/Renderer.asset"); }
            var volume=AssetDatabase.LoadAssetAtPath<VolumeProfile>("Assets/Dawnrail/Resources/DawnVolume.asset");
            if(volume==null) { volume=ScriptableObject.CreateInstance<VolumeProfile>();AssetDatabase.CreateAsset(volume,"Assets/Dawnrail/Resources/DawnVolume.asset");var bloom=volume.Add<Bloom>();bloom.intensity.Override(.25f);bloom.threshold.Override(1.25f);AssetDatabase.AddObjectToAsset(bloom,volume);EditorUtility.SetDirty(bloom);var tone=volume.Add<Tonemapping>();tone.mode.Override(TonemappingMode.ACES);AssetDatabase.AddObjectToAsset(tone,volume);EditorUtility.SetDirty(tone);EditorUtility.SetDirty(volume); }
            var settings=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/QualitySettings.asset")[0]);
            var levels=settings.FindProperty("m_QualitySettings");levels.arraySize=4;
            string[] names={"Low","Medium","High","Ultra"};int[] aa={1,2,4,8},resolution={512,1024,2048,2048};float[] distance={0,20,35,50};
            UniversalRenderPipelineAsset high=null;
            for(int i=0;i<4;i++) {
                string path="Assets/Dawnrail/Resources/Quality/"+i+".asset";var asset=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(path);
                if(asset==null) { asset=UniversalRenderPipelineAsset.Create(renderer);asset.name=names[i];AssetDatabase.CreateAsset(asset,path); }
                asset.msaaSampleCount=aa[i];asset.renderScale=i==0?.85f:1;asset.shadowDistance=distance[i];asset.shadowCascadeCount=i>=2?2:1;asset.supportsHDR=i>=2;asset.volumeProfile=volume;
                var serialized=new SerializedObject(asset);Set(serialized,"m_MainLightShadowsSupported",i>0);Set(serialized,"m_MainLightShadowmapResolution",resolution[i]);Set(serialized,"m_SoftShadowsSupported",i>=2);Set(serialized,"m_AdditionalLightsPerObjectLimit",i>=2?4:0);serialized.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(asset);
                var level=levels.GetArrayElementAtIndex(i);level.FindPropertyRelative("name").stringValue=names[i];level.FindPropertyRelative("customRenderPipeline").objectReferenceValue=asset;
                if(i==2)high=asset;
            }
            settings.ApplyModifiedPropertiesWithoutUndo();GraphicsSettings.defaultRenderPipeline=high;QualitySettings.SetQualityLevel(2,true);
            // The scene is procedural: keep variants needed by runtime instanced draws.
            var graphics=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0]);Set(graphics,"m_InstancingStripping",2);graphics.ApplyModifiedPropertiesWithoutUndo();
            if(!File.Exists("Assets/Dawnrail/Resources/TrainMaterial.mat")) { var mat=new Material(Shader.Find("Universal Render Pipeline/Lit"));mat.enableInstancing=true;AssetDatabase.CreateAsset(mat,"Assets/Dawnrail/Resources/TrainMaterial.mat"); }
            if(!File.Exists("Assets/Dawnrail/Resources/SteamMaterial.mat")) {
                var texture=new Texture2D(32,32,TextureFormat.RGBA32,false);for(int y=0;y<32;y++)for(int x=0;x<32;x++) { float radius=Vector2.Distance(new Vector2(x+.5f,y+.5f),new Vector2(16,16))/16;texture.SetPixel(x,y,new Color(1,1,1,Mathf.Pow(Mathf.Clamp01(1-radius),2))); }texture.Apply();
                File.WriteAllBytes("Assets/Dawnrail/Resources/Particle.png",texture.EncodeToPNG());UnityEngine.Object.DestroyImmediate(texture);AssetDatabase.Refresh();
                var mat=new Material(Shader.Find("Universal Render Pipeline/Particles/Unlit"));mat.SetTexture("_BaseMap",AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Dawnrail/Resources/Particle.png"));mat.SetFloat("_Surface",1);mat.SetFloat("_Blend",0);mat.SetFloat("_SrcBlend",(float)BlendMode.SrcAlpha);mat.SetFloat("_DstBlend",(float)BlendMode.OneMinusSrcAlpha);mat.SetFloat("_ZWrite",0);mat.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");mat.renderQueue=(int)RenderQueue.Transparent;AssetDatabase.CreateAsset(mat,"Assets/Dawnrail/Resources/SteamMaterial.mat");
            }
            PlayerSettings.companyName="Nightcity";PlayerSettings.productName="Поезд за рассветом";PlayerSettings.bundleVersion="0.5.1-dev";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android,"net.nightcity.dawnrail.unitytest");PlayerSettings.defaultInterfaceOrientation=UIOrientation.Portrait;PlayerSettings.defaultScreenWidth=540;PlayerSettings.defaultScreenHeight=960;
            PlayerSettings.colorSpace=ColorSpace.Linear;PlayerSettings.Android.minSdkVersion=AndroidSdkVersions.AndroidApiLevel24;PlayerSettings.Android.targetSdkVersion=AndroidSdkVersions.AndroidApiLevel35;
            PlayerSettings.Android.bundleVersionCode=2;PlayerSettings.Android.targetArchitectures=AndroidArchitecture.ARM64;PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android,ScriptingImplementation.IL2CPP);PlayerSettings.SetApiCompatibilityLevel(NamedBuildTarget.Android,ApiCompatibilityLevel.NET_Standard);
            var player=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset")[0]);Set(player,"activeInputHandler",0);player.ApplyModifiedPropertiesWithoutUndo();
            if(!File.Exists(Scene)) { var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);EditorSceneManager.SaveScene(scene,Scene); }
            EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(Scene,true)};AssetDatabase.SaveAssets();AssetDatabase.Refresh();
            Debug.Log("Dawnrail: project configured, separate Android test package. Open scene and Play.");
        }
        [MenuItem("Dawnrail/Build Android test APK")]
        public static void BuildAndroid()
        {
            Prepare();Directory.CreateDirectory("Builds");
            if(!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android,BuildTarget.Android))throw new InvalidOperationException("Android Build Support is unavailable");
            var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes=new[]{Scene},locationPathName="Builds/Dawnrail_Unity_0.5.1-test.apk",target=BuildTarget.Android,options=BuildOptions.Development });
            if(report.summary.result!=BuildResult.Succeeded)throw new InvalidOperationException("Android build failed: "+report.summary.totalErrors+" errors");
            Debug.Log("Dawnrail APK: "+report.summary.outputPath+" ("+report.summary.totalSize+" bytes)");
        }
        [MenuItem("Dawnrail/Open game scene")]
        public static void OpenScene() { Prepare();EditorSceneManager.OpenScene(Scene); }
    }
}
