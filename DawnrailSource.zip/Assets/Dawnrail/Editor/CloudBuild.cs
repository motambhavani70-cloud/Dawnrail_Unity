using System;
using System.IO;
using Dawnrail.Verification;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;

namespace Dawnrail.Editor
{
    public static class CloudBuild
    {
        // Unity Build Automation pre-export hook. Never starts a nested build.
        public static void PreExport()
        {
            ProjectBuilder.Prepare();
            EditorUserBuildSettings.buildAppBundle = false;
            PlayerSettings.Android.useCustomKeystore = false;
            int checks = VerificationSuite.Run(Directory.GetCurrentDirectory());
            if (EditorBuildSettings.scenes.Length != 1 || !EditorBuildSettings.scenes[0].enabled)
                throw new BuildFailedException("Dawnrail scene is missing from the build.");
            if (Resources.Load<Font>("Fonts/DejaVuSans") == null)
                throw new BuildFailedException("Cyrillic UI font is missing.");
            for (int quality = 0; quality < 4; quality++)
                if (Resources.Load<UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset>("Quality/" + quality) == null)
                    throw new BuildFailedException("Missing graphics profile: " + quality);
            Debug.Log("DAWNRAIL_CLOUD_VALIDATION_OK: " + checks + " checks, four graphics profiles, scene and Cyrillic font.");
        }
    }
}
