using System;
using System.Linq;
using Dawnrail.Core;
using Dawnrail.Unity;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Dawnrail.Editor
{
    // Creates the actual procedural scene and checks its object lifetimes and state bindings.
    // This does not substitute for rendered image or device performance checks.
    public static class SceneVerification
    {
        static int checks;
        static void Check(bool condition,string label) { checks++;if(!condition)throw new BuildFailedException("Dawnrail scene verification: "+label); }
        static bool Finite(Vector3 value) { return !float.IsNaN(value.x)&&!float.IsNaN(value.y)&&!float.IsNaN(value.z)&&!float.IsInfinity(value.x)&&!float.IsInfinity(value.y)&&!float.IsInfinity(value.z); }
        static TrainVisual.Vehicle Wagon(WorldScene world,string key) { return world.Train.Vehicles.First(v=>v.Key==key); }
        static int People(WorldScene world,string key) { return Wagon(world,key).Frame.GetComponentsInChildren<ResidentActivity>(true).Count(r=>r.gameObject.activeInHierarchy); }
        static void Motion(WorldScene world)
        {
            world.UpdateVisuals(1f/60);
            foreach(var vehicle in world.Train.Vehicles) { Check(Finite(vehicle.Frame.position)&&Finite(vehicle.Body.position),"finite vehicle "+vehicle.Key);Check(Math.Abs(vehicle.SpringY)<.05,"bounded suspension "+vehicle.Key); }
            Check(Finite(world.GetComponentInChildren<Camera>().transform.position),"finite camera");
            foreach(var person in world.GetComponentsInChildren<ResidentActivity>(true).Where(r=>r.gameObject.activeInHierarchy)) { person.Tick(5);Check(Finite(person.transform.position),"finite resident "+person.Activity); }
            var steam=world.transform.Find("Steam");Check(steam!=null&&steam.gameObject.activeSelf&&steam.GetComponent<ParticleSystem>()!=null,"steam survives rebuild");
        }
        public static int Run()
        {
            checks=0;
            var oldSky=RenderSettings.skybox;var oldFog=RenderSettings.fog;var oldFogMode=RenderSettings.fogMode;var oldFogColor=RenderSettings.fogColor;float oldDensity=RenderSettings.fogDensity;
            var oldAmbient=RenderSettings.ambientMode;var oldAmbientSky=RenderSettings.ambientSkyColor;var oldAmbientEquator=RenderSettings.ambientEquatorColor;var oldAmbientGround=RenderSettings.ambientGroundColor;
            int oldQuality=QualitySettings.GetQualityLevel(),oldFrameRate=Application.targetFrameRate,oldVsync=QualitySettings.vSyncCount;var oldPipeline=QualitySettings.renderPipeline;
            var root=new GameObject("Dawnrail scene verification");
            try {
                var state=new GameState(new GameContent(Resources.Load<TextAsset>("content").text));var world=root.AddComponent<WorldScene>();world.Create(state);
                Check(world.Train.Vehicles.Count==2,"initial train");Check(world.Train.FocusKey=="home","initial cutaway");
                Check(People(world,"home")==3,"three initial free residents");Check(People(world,"engine")==1,"driver without unassigned stoker");Motion(world);
                state.Distance=75;state.Velocity=2;world.UpdateVisuals(.2f);
                state.Wagons["garden"]=1;world.Refresh();world.Train.SetFocus(2);Motion(world);
                double springY=Wagon(world,"home").SpringY,springV=Wagon(world,"home").SpringV;Vector3 homePosition=Wagon(world,"home").Frame.position;
                state.Wagons["workshop"]=1;world.Refresh();
                Check(world.Train.FocusKey=="garden","focus follows wagon when another wagon is inserted");
                Check((Wagon(world,"home").Frame.position-homePosition).sqrMagnitude<1e-8f,"frame position survives rebuild");
                Check(Math.Abs(Wagon(world,"home").SpringY-springY)<1e-8&&Math.Abs(Wagon(world,"home").SpringV-springV)<1e-8,"suspension survives rebuild");
                Check(Wagon(world,"workshop").Frame.localPosition.sqrMagnitude>1,"new wagon has a rail pose immediately");
                Check(People(world,"workshop")==0&&People(world,"garden")==0,"unassigned workshops stay empty");
                Check(state.Assign("mechanic",1),"assign mechanic");world.Refresh();Check(People(world,"workshop")==1&&People(world,"home")==2,"mechanic moves from home");
                Check(state.Assign("gardener",1),"assign gardener");world.Refresh();Check(People(world,"garden")==1&&People(world,"home")==1,"gardener moves from home");
                Check(state.Assign("stoker",1),"assign stoker");world.Refresh();Check(People(world,"engine")==2&&People(world,"home")==0,"stoker moves from home");
                Check(Wagon(world,"engine").Frame.GetComponentsInChildren<ResidentActivity>().Any(r=>r.Activity=="stoke"),"stoker has shovel activity");
                state.Heat=state.Parts=10000;bool passengerChoice=false;int before=state.Passengers,region=state.Region;
                foreach(var station in state.Content.Events.Values) {
                    for(int i=0;i<station.Choices.Length;i++)if(Json.Num(Json.Get(station.Choices[i].Effects,"passengers"))>0) { state.Event=station.Id;passengerChoice=state.Choose(i);break; }
                    if(passengerChoice)break;
                }
                Check(passengerChoice&&state.Passengers>before&&state.Region==region,"passenger event within same region");
                Check(world.Train.NeedsRefresh,"event invalidates resident visuals");world.Refresh();Check(People(world,"home")==Math.Min(5,state.FreePassengers),"new residents appear without a biome change");
                Check(!world.Train.NeedsRefresh,"scene catches up to game state");
                state.Wagons["home"]=5;world.Refresh();Check(Wagon(world,"home").Frame.GetComponentsInChildren<Transform>(true).Any(t=>t.name=="Teapot"),"level five interior upgrade");
                Color winterFog=Color.clear;
                for(int biome=0;biome<7;biome++) {
                    state.Station=biome*3;world.Refresh();Motion(world);
                    Check(world.Curved==(biome!=2&&biome!=4),"route shape for biome "+biome);
                    Check(world.transform.Find("Snow").gameObject.activeSelf==(biome==0||biome==5),"snow for biome "+biome);
                    if(biome==0)winterFog=RenderSettings.fogColor;
                }
                Check(Vector4.Distance(winterFog,RenderSettings.fogColor)>.2f,"warm biome palette differs from winter");
                state.Station=0;
                int[] aa={1,2,4,8};float[] shadows={0,20,35,50};
                for(int quality=0;quality<4;quality++) {
                    state.Quality=quality;world.Refresh();Motion(world);var pipeline=QualitySettings.renderPipeline as UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset;
                    Check(pipeline==Resources.Load<RenderPipelineAsset>("Quality/"+quality),"active pipeline "+quality);
                    Check(pipeline.msaaSampleCount==aa[quality]&&Math.Abs(pipeline.shadowDistance-shadows[quality])<.001,"quality affects MSAA and shadows "+quality);
                    Check(world.GetComponentInChildren<Camera>().GetUniversalAdditionalCameraData().renderPostProcessing==(quality>=2),"post processing profile "+quality);
                }
                state.Economy=true;world.Refresh();Check(Application.targetFrameRate==30&&!world.transform.Find("Snow").gameObject.activeSelf,"battery mode affects frame rate and snow");
                Check(world.transform.Find("Steam").GetComponent<ParticleSystem>().emission.rateOverTime.constant==0,"battery mode stops steam emission");
                var graphics=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0]);Check(graphics.FindProperty("m_InstancingStripping").intValue==2,"runtime instancing variants retained");
                Check(world.GetComponentsInChildren<Collider>(true).Length==0,"decorative geometry has no stale colliders");
                return checks;
            } finally {
                RenderSettings.skybox=oldSky;RenderSettings.fog=oldFog;RenderSettings.fogMode=oldFogMode;RenderSettings.fogColor=oldFogColor;RenderSettings.fogDensity=oldDensity;
                RenderSettings.ambientMode=oldAmbient;RenderSettings.ambientSkyColor=oldAmbientSky;RenderSettings.ambientEquatorColor=oldAmbientEquator;RenderSettings.ambientGroundColor=oldAmbientGround;
                UnityEngine.Object.DestroyImmediate(root);QualitySettings.SetQualityLevel(oldQuality,true);QualitySettings.renderPipeline=oldPipeline;Application.targetFrameRate=oldFrameRate;QualitySettings.vSyncCount=oldVsync;
            }
        }
    }
}
