using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Dawnrail.Core;

namespace Dawnrail.CloudVerification
{
    public static class VerificationSuite
    {
        static int checks;static GameContent content;
        static void Check(bool valid,string message) { checks++;if(!valid)throw new Exception("FAIL: "+message); }
        static void Near(double a,double b,string message,double tolerance=1e-7) { Check(Math.Abs(a-b)<=tolerance*Math.Max(1,Math.Abs(b)),message+": "+a+" != "+b); }
        public static int Run(string projectRoot)
        {
            checks=0;string json=File.ReadAllText(Path.Combine(projectRoot,"Assets/Dawnrail/Resources/content.json"));content=new GameContent(json);
            var root=Json.Map(Json.Parse(json));var s=new GameState(content);Check(s.Load(root["fixture_save"]),"legacy fixture load");var expected=Json.Map(root["fixture_expected"]);
            Near(s.Cruise,Json.Num(expected["cruise_mps"]),"speed parity");Near(s.HeatRate,Json.Num(expected["heat_per_second"]),"heat parity");Near(s.PartsRate,Json.Num(expected["parts_per_second"]),"parts parity");Near(s.TapPower,Json.Num(expected["tap_power"]),"tap parity");
            Check(content.Events.Count==15,"all events");Check(content.Regions.Length==7,"all regions");
            foreach(var e in content.Events.Values)for(int c=0;c<2;c++) { s=new GameState(content);s.Heat=s.Parts=10000;s.Event=e.Id;Check(s.Choose(c),"choose "+e.Id+":"+c);Check(s.Station==1&&s.NextStation==380&&s.Event=="","station transition "+e.Id);Check(!s.Choose(c),"prevent duplicate event reward"); }
            s=new GameState(content);s.Heat=100;s.Parts=100;Check(s.Buy("engine"),"buy engine");Near(s.Heat,45,"buy heat");Near(s.Parts,88,"buy parts");Check(s.Engine==2,"buy level");Check(!s.Buy("unknown"),"reject unknown upgrade");
            s=new GameState(content);Check(s.Assign("stoker",1),"assign stoker");Check(!s.Assign("stoker",1),"capacity");Near(s.HeatRate,1.3,"worker effect");Check(s.Assign("stoker",-1),"release worker");Check(!s.Assign("stoker",-1),"no negative workers");Check(!s.Assign("gardener",1),"missing wagon capacity");
            var bad=Json.Map(Json.Parse("{\"version\":1,\"heat\":-90,\"scrap\":\"9999\",\"engine\":900,\"passengers\":2,\"wagons\":{\"home\":0,\"garden\":99},\"jobs\":{\"stoker\":8,\"gardener\":8},\"graphics_quality\":99,\"story_rewards\":[\"Город в пути\"]}"));
            Check(s.Load(bad),"sanitize save");Check(s.Heat==0&&s.Parts==40&&s.Engine==50&&s.Wagons["home"]==1&&s.Wagons["garden"]==50,"value clamps");Check(s.Jobs.Values.Sum()<=2&&s.Quality==3&&s.StoryRewards.Count==0,"sanitized jobs, quality, chapters");
            Check(!s.Load(Json.Parse("{\"version\":2}")),"future save rejected");Check(!s.Load(Json.Parse("[]")),"save root rejected");
            foreach(string invalid in new[]{"","{","[1,]","{\"x\":1,}","{\"x\":1,\"x\":2}","01","NaN","1e999","true false","\"raw\nnewline\"",".2","1.","1e"}) { bool threw=false;try { Json.Parse(invalid); }catch(FormatException) { threw=true; }Check(threw,"strict JSON "+invalid); }
            string sample="Снег · чай\n\"Поезд\" \\ / ☀";Check((string)Json.Parse(Json.Stringify(sample))==sample,"unicode JSON roundtrip");
            foreach(int fps in new[]{15,30,60,144}) { s=new GameState(content);for(int i=0;i<fps*100;i++)s.Online(1.0/fps);Near(s.Distance,180,"exact stop "+fps,1e-9);Check(s.Velocity==0&&s.Event.Length>0,"arrival "+fps);Near(s.Heat,70,"frame production "+fps); }
            s=new GameState(content);s.Offline(86400);Near(s.Heat,.7*28800,"offline capped");Check(s.Distance==180&&s.Event.Length>0,"offline stops at first station");double d=s.Distance;s.Offline(100);Check(s.Distance==d,"pending event stops offline travel");
            s=new GameState(content);s.Engine=6;s.Wagons["home"]=s.Wagons["workshop"]=s.Wagons["garden"]=3;s.Station=18;s.Helped=5;s.Taps=25;s.Distance=1000;s.ClaimRewards();Check(s.Rewards.Count==8&&s.StoryRewards.Count==3,"all rewards");double rewardHeat=s.Heat,rewardParts=s.Parts;s.ClaimRewards();Near(s.Heat,rewardHeat,"no repeated chapter reward");Near(s.Parts,rewardParts,"no repeated achievement reward");
            for(int i=-800;i<800;i++) { double a=i*.2;var p=RailPath.Point(a);var q=RailPath.Point(a+.2);double length=Math.Sqrt(Math.Pow(q.X-p.X,2)+Math.Pow(q.Z-p.Z,2));Near(length,.2,"arc length "+i,2e-5);double curvature=Math.Abs(RailPath.Heading(a+.2)-RailPath.Heading(a))/.2;Check(curvature<1.0/40,"curve radius "+i); }
            foreach(double at in new[]{0,40,80,160,-40,1e15}) { var p=RailPath.Pose(0,at,true);Near(p.X,0,"anchor X");Near(p.Z,0,"anchor Z"); }
            var one=RailMotion.Spring(.025,0,0,11,1);var two=RailMotion.Spring(.025,0,0,11,.5);two=RailMotion.Spring(two.Distance,two.Velocity,0,11,.5);Near(one.Distance,two.Distance,"spring frame independence",1e-10);
            string directory=Path.Combine(Path.GetTempPath(),"Dawnrail-test-"+Guid.NewGuid());Directory.CreateDirectory(directory);
            try {
                var repo=new SaveRepository(directory,content);s=new GameState(content);s.Heat=100;Check(repo.Save(s,1000),"save primary");s.Heat=200;Check(repo.Save(s,1000),"save backup");
                File.WriteAllText(Path.Combine(directory,"journey.json"),"broken");s=new GameState(content);double away;Check(repo.Load(s,1010,out away),"backup recovery");Near(s.Heat,107,"backup + offline");Check(repo.Load(s,1010,out away)&&away==0,"offline awarded once");Near(s.Heat,107,"no double offline");
                string imported=Json.Stringify(new GameState(content).Snapshot(1000));Check(repo.Import(imported,s,1020),"import legacy schema");Near(s.Heat,14,"import offline");Check(!repo.Import(imported,s,1030),"duplicate import receipt");Check(!repo.Import("{bad",s,1030),"invalid import");Near(s.Heat,14,"invalid import preserves state");
                Check(repo.Load(s,900,out away)&&away==0,"clock reversal");
            } finally { Directory.Delete(directory,true); }
            CompareGodotGoldens(Path.Combine(projectRoot,"Verification/godot-goldens.json"));return checks;
        }
        static void CompareGodotGoldens(string file)
        {
            foreach(object item in Json.List(Json.Parse(File.ReadAllText(file)))) {
                var row=Json.Map(item);var state=new GameState(content);Check(state.Load(row["before"]),"golden load");state.Velocity=Json.Num(row["velocity_before"]);
                var action=Json.Map(row["action"]);string kind=Json.Str(action["kind"]);double n=Json.Num(Json.Get(action,"amount"),0,-1e15);string key=Json.Str(Json.Get(action,"key"));
                switch(kind) { case "tap":state.Tap();break;case "online":state.Online(n);break;case "offline":state.Offline(n);break;case "buy":state.Buy(key);break;case "assign":state.Assign(key,(int)n);break;case "choose":state.Choose((int)n);break;case "rewards":state.ClaimRewards();break;default:throw new Exception("Unknown golden action"); }
                Compare(row["after"],Json.Parse(Json.Stringify(state.Snapshot(1000))),Json.Str(row["label"]));
                Near(state.Velocity,Json.Num(row["velocity_after"]),Json.Str(row["label"])+" velocity",2e-6);
            }
        }
        static void Compare(object expected,object actual,string key)
        {
            if(expected is Dictionary<string,object>) { var a=Json.Map(actual);foreach(var item in (Dictionary<string,object>)expected) { Check(a.ContainsKey(item.Key),key+" field "+item.Key);Compare(item.Value,a[item.Key],key+"/"+item.Key); } }
            else if(expected is List<object>) { var e=Json.List(expected);var a=Json.List(actual);Check(e.Count==a.Count,key+" list count");for(int i=0;i<e.Count;i++)Compare(e[i],a[i],key+"/"+i); }
            else if(expected is double)Near(Json.Num(actual,0,-1e15), (double)expected,key,2e-6);
            else Check(Equals(expected,actual),key+" equality");
        }
    }
}
