using UnityEngine;
using UnityEngine.EventSystems;

namespace Dawnrail.Unity
{
    public sealed class HoldButton : MonoBehaviour,IPointerDownHandler,IPointerUpHandler,IPointerExitHandler
    {
        public DawnrailGame Game;bool held;float duration,repeat;
        public void OnPointerDown(PointerEventData e) { if(e.button!=PointerEventData.InputButton.Left)return;held=true;duration=repeat=0;Game.Tap(); }
        public void OnPointerUp(PointerEventData e) { held=false; }
        public void OnPointerExit(PointerEventData e) { held=false; }
        void OnDisable() { held=false; }
        void OnApplicationPause(bool pause) { if(pause)held=false; }
        void Update() { if(!held)return;float old=duration;duration+=Time.unscaledDeltaTime;repeat+=Mathf.Max(0,duration-.4f)-Mathf.Max(0,old-.4f);int count=0;while(repeat>=.09f&&count++<8) { Game.Tap();repeat-=.09f; } }
    }
    public sealed class ViewGesture : MonoBehaviour,IBeginDragHandler,IDragHandler,IEndDragHandler
    {
        public DawnrailGame Game;Vector2 begin;bool pinched;float pinch;
        public void OnBeginDrag(PointerEventData e) { begin=e.position;pinched=false; }
        public void OnDrag(PointerEventData e) { }
        public void OnEndDrag(PointerEventData e) { if(pinched)return;float delta=e.position.x-begin.x;if(Mathf.Abs(delta)>45) { var train=Game.World.Train;train.SetFocus(train.Focus+(delta>0?-1:1));Game.UI.Refresh(); } }
        void Update() { if(Input.touchCount==2) { pinched=true;float distance=Vector2.Distance(Input.GetTouch(0).position,Input.GetTouch(1).position);if(pinch>0)Game.World.Zoom((pinch-distance)*.015f);pinch=distance; } else pinch=0;if(Input.mouseScrollDelta.y!=0)Game.World.Zoom(-Input.mouseScrollDelta.y*.5f); }
    }
}
