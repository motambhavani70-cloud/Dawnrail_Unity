using System.Collections.Generic;
using UnityEngine;

namespace Dawnrail.Unity
{
    public sealed class Geometry
    {
        readonly Dictionary<string,Material> materials=new Dictionary<string,Material>();
        readonly Dictionary<string,Mesh> meshes=new Dictionary<string,Mesh>();
        public int Detail=2;
        public Material Material(Color color,float metal=0,float smooth=.35f)
        {
            string key=ColorUtility.ToHtmlStringRGBA(color)+":"+metal+":"+smooth;
            Material material; if(materials.TryGetValue(key,out material))return material;
            material=new Material(Resources.Load<Material>("TrainMaterial")); material.name=key;material.enableInstancing=true;
            material.SetColor("_BaseColor",color); material.SetFloat("_Metallic",metal); material.SetFloat("_Smoothness",smooth); materials.Add(key,material); return material;
        }
        public Transform Node(string name,Transform parent,Vector3 position)
        {
            var go=new GameObject(name); go.transform.SetParent(parent,false); go.transform.localPosition=position; return go.transform;
        }
        public Transform Box(string name,Transform parent,Vector3 pos,Vector3 size,Color color,float radius=.06f,float metal=0)
        {
            string key=size+":"+radius+":"+Detail; Mesh mesh;
            if(!meshes.TryGetValue(key,out mesh)) { mesh=Rounded(size,radius,Detail==0?2:4); meshes.Add(key,mesh); }
            var t=Node(name,parent,pos); t.gameObject.AddComponent<MeshFilter>().sharedMesh=mesh; t.gameObject.AddComponent<MeshRenderer>().sharedMaterial=Material(color,metal); return t;
        }
        public Transform Sphere(string name,Transform parent,Vector3 pos,Vector3 scale,Color color,float metal=0)
        {
            var go=GameObject.CreatePrimitive(PrimitiveType.Sphere); go.name=name; Object.Destroy(go.GetComponent<Collider>()); go.transform.SetParent(parent,false); go.transform.localPosition=pos; go.transform.localScale=scale;
            go.GetComponent<MeshRenderer>().sharedMaterial=Material(color,metal); return go.transform;
        }
        public Transform Cylinder(string name,Transform parent,Vector3 pos,float radius,float height,Color color,Vector3 rotation,float metal=0)
        {
            var go=GameObject.CreatePrimitive(PrimitiveType.Cylinder); go.name=name; Object.Destroy(go.GetComponent<Collider>()); go.transform.SetParent(parent,false); go.transform.localPosition=pos; go.transform.localScale=new Vector3(radius*2,height*.5f,radius*2); go.transform.localRotation=Quaternion.Euler(rotation);
            go.GetComponent<MeshRenderer>().sharedMaterial=Material(color,metal); return go.transform;
        }
        public Transform Limb(string name,Transform parent,Vector3 top,float length,float radius,Color color)
        {
            var pivot=Node(name,parent,top); Cylinder(name+" mesh",pivot,new Vector3(0,-length*.5f,0),radius,length,color,Vector3.zero); Sphere("Joint",pivot,Vector3.zero,Vector3.one*radius*2,color); return pivot;
        }
        public Transform Beam(string name,Transform parent,Vector3 a,Vector3 b,float width,Color color)
        {
            var t=Box(name,parent,(a+b)*.5f,new Vector3((b-a).magnitude,width,width),color,width*.25f); t.localRotation=Quaternion.FromToRotation(Vector3.right,b-a); return t;
        }
        static Mesh Rounded(Vector3 size,float radius,int steps)
        {
            Vector3 half=size*.5f; radius=Mathf.Min(radius,Mathf.Min(half.x,Mathf.Min(half.y,half.z))*.9f);
            Vector3 core=half-Vector3.one*radius; var verts=new List<Vector3>(); var normals=new List<Vector3>(); var uv=new List<Vector2>(); var indices=new List<int>();
            Vector3[] ns={Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back};
            foreach(Vector3 n in ns) {
                Vector3 u=Mathf.Abs(n.y)>.5f?Vector3.right:Vector3.up,v=Vector3.Cross(n,u);
                float hn=Vector3.Dot(half,new Vector3(Mathf.Abs(n.x),Mathf.Abs(n.y),Mathf.Abs(n.z)));
                float hu=Vector3.Dot(half,new Vector3(Mathf.Abs(u.x),Mathf.Abs(u.y),Mathf.Abs(u.z))),hv=Vector3.Dot(half,new Vector3(Mathf.Abs(v.x),Mathf.Abs(v.y),Mathf.Abs(v.z)));
                int first=verts.Count;
                for(int y=0;y<=steps;y++)for(int x=0;x<=steps;x++) {
                    Vector3 p=n*hn+u*hu*(2f*x/steps-1)+v*hv*(2f*y/steps-1);
                    Vector3 c=new Vector3(Mathf.Clamp(p.x,-core.x,core.x),Mathf.Clamp(p.y,-core.y,core.y),Mathf.Clamp(p.z,-core.z,core.z));
                    Vector3 norm=(p-c).normalized; verts.Add(c+norm*radius); normals.Add(norm); uv.Add(new Vector2((float)x/steps,(float)y/steps));
                }
                for(int y=0;y<steps;y++)for(int x=0;x<steps;x++) { int a=first+y*(steps+1)+x,b=a+1,c=a+steps+1,d=c+1; indices.Add(a);indices.Add(b);indices.Add(c);indices.Add(b);indices.Add(d);indices.Add(c); }
            }
            var mesh=new Mesh { name="Rounded box" }; mesh.SetVertices(verts);mesh.SetNormals(normals);mesh.SetUVs(0,uv);mesh.SetTriangles(indices,0);mesh.RecalculateBounds(); return mesh;
        }
        public void Dispose() { foreach(var m in materials.Values)Release(m); foreach(var m in meshes.Values)Release(m); materials.Clear();meshes.Clear(); }
        static void Release(Object obj) { if(Application.isPlaying)Object.Destroy(obj);else Object.DestroyImmediate(obj); }
    }
}
