using System;
using System.Collections.Generic;
using System.Linq;
using Dawnrail.Core;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Dawnrail.Unity
{
    public sealed class GameUI : MonoBehaviour
    {
        DawnrailGame game;GameState s;RectTransform safe,nav;GameObject overlay;RectTransform cards;ScrollRect scroll;Font font;Sprite rounded;
        Text heat,parts,rate,region,focus,notice,tapText;Button station;Image progress;float toastTime;int panel=-1;Rect oldSafe;Vector2 oldSize;
        readonly List<Action> updates=new List<Action>();
        static readonly Color Ink=H("172825"),Panel=H("233b35"),Card=H("304b42"),TextColor=H("f5f0dc"),Muted=H("c2c7ad"),Gold=H("edc27c"),Accent=H("426c56");
        static Color H(string hex) { Color c;ColorUtility.TryParseHtmlString("#"+hex,out c);return c; }
        static readonly string[] Keys={"engine","fire","crew","home","workshop","garden"};
        static readonly string[] Names={"Двигатель","Сердце звезды","Кочегары","Жилой вагон","Мастерская","Оранжерея"};
        static readonly string[] Benefits={"Быстрее к следующим станциям","Больше тепла за нажатие","+1,5 тепла/с за уровень","+4 п.п. к бонусу автотепла за уровень","+0,18 деталей/с за уровень","+0,8 тепла/с и +0,06 деталей/с"};
        public static string Number(double value) { if(value>=1e9)return (value/1e9).ToString("0.0")+" млрд";if(value>=1e6)return (value/1e6).ToString("0.0")+" млн";if(value>=10000)return (value/1000).ToString("0.0")+" тыс";return value.ToString(value<10?"0.0":"0"); }
        public void Create(DawnrailGame owner)
        {
            game=owner;s=owner.State;font=Resources.Load<Font>("Fonts/DejaVuSans");rounded=Rounded();
            var canvas=gameObject.AddComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;gameObject.AddComponent<GraphicRaycaster>();
            var scaler=gameObject.AddComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(540,960);scaler.matchWidthOrHeight=0;
            if(FindFirstObjectByType<EventSystem>()==null)new GameObject("Touch events",typeof(EventSystem),typeof(StandaloneInputModule));
            safe=Rect("Safe area",transform);safe.anchorMin=Vector2.zero;safe.anchorMax=Vector2.one;safe.offsetMin=safe.offsetMax=Vector2.zero;FitSafeArea();
            var header=At("Header",safe,new Vector2(0,1),new Vector2(1,1),new Vector2(0,-138),new Vector2(0,0));Image(header,Ink);
            var title=Fixed("Title",header,18,12,410,30);Label(title,"ПОЕЗД ЗА РАССВЕТОМ",20,Gold);
            var settings=Fixed("Settings",header,466,8,56,50);Button(settings,"•••",()=>Show(4));
            heat=Label(Fixed("Heat",header,18,52,260,35),"",25);parts=Label(Fixed("Parts",header,290,52,230,35),"",23);
            region=Label(Fixed("Region",header,18,96,370,27),"",16,Muted);
            station=Button(Fixed("Station",header,388,94,134,34),"",()=>ShowEvent(),14);
            var bar=Fixed("Route",header,18,130,504,4);Image(bar,Card);progress=Image(At("Fill",bar,Vector2.zero,Vector2.one,Vector2.zero,Vector2.zero),Gold);
            var view=At("View gesture",safe,new Vector2(0,.3f),new Vector2(1,1),new Vector2(0,0),new Vector2(0,-138));Image(view,new Color(0,0,0,0));view.gameObject.AddComponent<ViewGesture>().Game=game;
            var footer=At("Furnace panel",safe,Vector2.zero,new Vector2(1,0),new Vector2(0,82),new Vector2(0,213));Image(footer,Ink);
            rate=Label(Fixed("Rates",footer,18,8,504,25),"",16,Muted);
            var fire=Fixed("Furnace",footer,18,40,504,77);Button(fire,"",null);fire.gameObject.AddComponent<HoldButton>().Game=game;tapText=Label(Fixed("Fire label",fire,8,5,488,66),"РАЗЖЕЧЬ ЗВЕЗДУ\nНажмите или удерживайте",23,TextColor,TextAnchor.MiddleCenter);
            var wagon=At("Wagon selector",safe,Vector2.zero,new Vector2(1,0),new Vector2(18,220),new Vector2(-18,270));
            Button(Fixed("Previous",wagon,0,0,60,50),"‹",()=> { game.World.Train.SetFocus(game.World.Train.Focus-1);Refresh(); },28);
            focus=Label(Fixed("Current wagon",wagon,68,0,364,50),"",19,TextColor,TextAnchor.MiddleCenter);
            Button(Fixed("Next",wagon,444,0,60,50),"›",()=> { game.World.Train.SetFocus(game.World.Train.Focus+1);Refresh(); },28);
            nav=At("Navigation",safe,Vector2.zero,new Vector2(1,0),new Vector2(0,8),new Vector2(0,73));Image(nav,Ink);
            string[] tabs={"Поезд","Маршрут","Жители","Цели"};for(int i=0;i<4;i++) { int tab=i;Button(Fixed(tabs[i],nav,8+i*133,4,125,57),tabs[i],()=> { if(panel==tab)Close();else Show(tab); },18); }
            notice=Label(At("Toast",safe,new Vector2(0,.79f),new Vector2(1,.89f),new Vector2(22,0),new Vector2(-22,0)),"",17,Gold,TextAnchor.MiddleCenter);notice.raycastTarget=false;
            Refresh();
        }
        RectTransform Rect(string name,Transform parent) { var go=new GameObject(name,typeof(RectTransform));go.transform.SetParent(parent,false);return (RectTransform)go.transform; }
        RectTransform At(string name,Transform parent,Vector2 min,Vector2 max,Vector2 low,Vector2 high) { var r=Rect(name,parent);r.anchorMin=min;r.anchorMax=max;r.offsetMin=low;r.offsetMax=high;return r; }
        RectTransform Fixed(string name,Transform parent,float x,float y,float width,float height) { var r=Rect(name,parent);r.anchorMin=r.anchorMax=new Vector2(0,1);r.pivot=new Vector2(0,1);r.anchoredPosition=new Vector2(x,-y);r.sizeDelta=new Vector2(width,height);return r; }
        Image Image(RectTransform r,Color color) { var image=r.gameObject.AddComponent<Image>();image.color=color;image.sprite=rounded;image.type=UnityEngine.UI.Image.Type.Sliced;return image; }
        Text Label(RectTransform r,string value,int size,Color? color=null,TextAnchor alignment=TextAnchor.MiddleLeft) { var t=r.gameObject.AddComponent<Text>();t.font=font;t.fontSize=size;t.color=color??TextColor;t.text=value;t.alignment=alignment;t.horizontalOverflow=HorizontalWrapMode.Wrap;t.verticalOverflow=VerticalWrapMode.Truncate;t.raycastTarget=false;return t; }
        Button Button(RectTransform r,string value,Action action,int size=18)
        {
            Image(r,Accent);var b=r.gameObject.AddComponent<Button>();var c=b.colors;c.highlightedColor=new Color(1.15f,1.15f,1.1f);c.pressedColor=new Color(.8f,.8f,.7f);c.disabledColor=new Color(.52f,.56f,.5f);b.colors=c;
            Label(At("Label",r,Vector2.zero,Vector2.one,new Vector2(8,3),new Vector2(-8,-3)),value,size,null,TextAnchor.MiddleCenter);if(action!=null)b.onClick.AddListener(()=>action());return b;
        }
        RectTransform CardBox(float height) { var r=Rect("Card",cards);var le=r.gameObject.AddComponent<LayoutElement>();le.preferredHeight=height;le.minHeight=height;Image(r,Card);return r; }
        void Paragraph(string value,float height=80,int size=17) { var card=CardBox(height);Label(At("Text",card,Vector2.zero,Vector2.one,new Vector2(14,8),new Vector2(-14,-8)),value,size); }
        void Open(string title)
        {
            if(overlay) { overlay.SetActive(false);Destroy(overlay); }updates.Clear();
            var r=At("Overlay",safe,new Vector2(0,.085f),Vector2.one,Vector2.zero,Vector2.zero);overlay=r.gameObject;Image(r,new Color(.04f,.08f,.06f,.66f));
            var sheet=At("Sheet",r,new Vector2(.02f,.0f),new Vector2(.98f,.88f),Vector2.zero,Vector2.zero);Image(sheet,Panel);
            Label(At("Heading",sheet,new Vector2(0,1),new Vector2(1,1),new Vector2(18,-66),new Vector2(-120,-8)),title,26,Gold);
            Button(At("Close",sheet,new Vector2(1,1),new Vector2(1,1),new Vector2(-110,-61),new Vector2(-12,-10)),"Готово",Close,17);
            var viewport=At("Scroll",sheet,Vector2.zero,Vector2.one,new Vector2(10,12),new Vector2(-10,-75));Image(viewport,new Color(0,0,0,0));viewport.gameObject.AddComponent<RectMask2D>();
            scroll=viewport.gameObject.AddComponent<ScrollRect>();scroll.horizontal=false;scroll.movementType=ScrollRect.MovementType.Clamped;scroll.viewport=viewport;scroll.scrollSensitivity=26;
            cards=Rect("Content",viewport);cards.anchorMin=new Vector2(0,1);cards.anchorMax=new Vector2(1,1);cards.pivot=new Vector2(.5f,1);cards.sizeDelta=Vector2.zero;
            var layout=cards.gameObject.AddComponent<VerticalLayoutGroup>();layout.spacing=10;layout.childControlWidth=true;layout.childControlHeight=true;layout.childForceExpandWidth=true;layout.childForceExpandHeight=false;
            cards.gameObject.AddComponent<ContentSizeFitter>().verticalFit=ContentSizeFitter.FitMode.PreferredSize;scroll.content=cards;nav.SetAsLastSibling();
        }
        public void Show(int tab) { panel=tab;Open(new[]{"Мой поезд","Маршрут","Жители и работа","Цели путешествия","Настройки","Перенос прогресса"}[tab]);switch(tab) { case 0:TrainPanel();break;case 1:RoutePanel();break;case 2:Residents();break;case 3:Goals();break;case 4:Settings();break;case 5:Transfer();break; }Refresh(); }
        public void Close() { if(overlay) { overlay.SetActive(false);Destroy(overlay); }panel=-1;updates.Clear(); }
        public void RebuildPanel() { if(panel<0)return;int tab=panel;float position=scroll?scroll.verticalNormalizedPosition:1;if(tab==6)ShowEvent();else Show(tab);Canvas.ForceUpdateCanvases();if(scroll)scroll.verticalNormalizedPosition=position; }
        public void Refresh()
        {
            heat.text="Тепло  "+Number(s.Heat);parts.text="Детали  "+Number(s.Parts);rate.text="+"+Number(s.HeatRate)+" тепла/с   ·   +"+Number(s.PartsRate)+" деталей/с";region.text=s.Content.Regions[s.Region];
            station.GetComponentInChildren<Text>().text=s.Event.Length>0?"Остановка":"Ещё "+Number(Math.Max(0,s.NextStation-s.Distance))+" м";station.interactable=s.Event.Length>0;
            double previous=s.Station==0?0:s.NextStation-(180+Math.Min(360,s.Station*20));
            progress.rectTransform.anchorMax=new Vector2((float)Math.Max(0,Math.Min(1,(s.Distance-previous)/Math.Max(1,s.NextStation-previous))),1);
            string key=game.World.Train.FocusKey;int i=Array.IndexOf(Keys,key);focus.text=Names[i]+" · ур. "+s.Level(key);
            foreach(var update in updates)update();
        }
        void TrainPanel()
        {
            Paragraph("Улучшения меняют доходы и облик поезда. Выберите вагон стрелками, чтобы увидеть его интерьер.",85);
            for(int i=0;i<Keys.Length;i++) {
                string key=Keys[i];var card=CardBox(173);var title=Label(Fixed("Name",card,14,7,458,31),"",23,Gold);
                Label(Fixed("Benefit",card,14,40,458,28),Benefits[i],15,Muted);Label(Fixed("Milestone",card,14,69,458,39),Milestone(key),14,TextColor);
                var buy=Button(Fixed("Buy",card,14,115,458,47),"",()=>game.Buy(key),17);
                updates.Add(()=> { title.text=Names[Array.IndexOf(Keys,key)]+" · ур. "+s.Level(key);var c=s.Cost(key);buy.GetComponentInChildren<Text>().text=s.Level(key)>=50?"Максимальный уровень":"Улучшить · "+Number(c[0])+" тепла / "+Number(c[1])+" деталей";buy.interactable=s.CanBuy(key); });
            }
        }
        string Milestone(string key)
        {
            string[] names;int[] levels;
            if(key=="engine") { levels=new[]{2,3,5,6,7,10};names=new[]{"манометры","золотые полосы","дополнительная труба","отделка крыши","фонари","броня котла"}; }
            else { levels=new[]{2,3,5,6,10};names=key=="home"?new[]{"книжная полка","купе на крыше","чайный сервиз","часы","ковёр и растения"}:key=="workshop"?new[]{"инструменты","вытяжка на крыше","пресс","рабочая лампа","шкаф деталей"}:new[]{"цветы","теплица на крыше","плоды","лампа роста","полка рассады"}; }
            if(key=="fire"||key=="crew")return "Поддерживает огонь и помогает путешествовать";
            for(int i=0;i<levels.Length;i++)if(s.Level(key)<levels[i])return "На уровне "+levels[i]+": "+names[i];return "Все изменения облика открыты";
        }
        void RoutePanel()
        {
            var info=CardBox(105);var text=Label(At("Travel",info,Vector2.zero,Vector2.one,new Vector2(14,8),new Vector2(-14,-8)),"",18);
            updates.Add(()=>text.text="Пройдено "+Number(s.Distance)+" м · "+(s.Velocity*3.6).ToString("0.0")+" км/ч\nОстановок: "+s.Station+" · путь "+(s.Route=="risk"?"быстрый +20%":"спокойный")+"\nПовороты чередуются с прямыми участками.");
            for(int i=0;i<s.Content.Regions.Length;i++)Paragraph((i==s.Region?"Сейчас · ":i<s.Region?"Пройдено · ":"Впереди · ")+s.Content.Regions[i],59,18);
            Paragraph("Журнал станций\n"+(s.Journal.Count>0?string.Join("\n",s.Journal.AsEnumerable().Reverse().Take(5)):"Первая история ждёт на ближайшей остановке."),s.Journal.Count>0?220:95,16);
        }
        void Residents()
        {
            var info=CardBox(97);var title=Label(At("Population",info,Vector2.zero,Vector2.one,new Vector2(14,8),new Vector2(-14,-8)),"",18);
            updates.Add(()=>title.text="Жителей: "+s.Passengers+" · свободны: "+s.FreePassengers+"\nНазначайте людей: каждый работник увеличивает производство. Их представители работают в вагонах.");
            string[] jobs={"stoker","mechanic","gardener"},names={"Кочегары · Лада","Механики · Роман","Садовники · Мира"},benefits={"Каждый: +0,6 тепла/с","Каждый: +0,12 деталей/с","Каждый: +0,25 тепла/с и +0,04 деталей/с"};
            for(int i=0;i<3;i++) {
                string job=jobs[i];var card=CardBox(172);Label(Fixed("Name",card,14,8,458,32),names[i],22,Gold);Label(Fixed("Effect",card,14,45,458,26),benefits[i],15);
                var count=Label(Fixed("Count",card,95,81,286,49),"",18,null,TextAnchor.MiddleCenter);
                var minus=Button(Fixed("Remove",card,14,81,67,49),"−",()=>game.Assign(job,-1),25);var plus=Button(Fixed("Add",card,397,81,75,49),"+",()=>game.Assign(job,1),25);
                Button(Fixed("Visit",card,14,137,458,28),"Показать рабочий вагон",()=> { string wagon=job=="stoker"?"engine":job=="mechanic"?"workshop":"garden";int index=game.World.Train.Vehicles.ToList().FindIndex(v=>v.Key==wagon);if(index<0) { Toast("Сначала постройте вагон");return; }game.World.Train.SetFocus(index);Close();Refresh(); },14);
                updates.Add(()=> { count.text=s.Jobs[job]+" / "+s.Capacity(job)+" мест";minus.interactable=s.Jobs[job]>0;plus.interactable=s.FreePassengers>0&&s.Jobs[job]<s.Capacity(job); });
            }
        }
        void Goals()
        {
            string[][] requirements={new[]{"Двигатель уровня 3","Мастерская построена","Оранжерея построена"},new[]{"Жильё уровня 3","9 остановок","Помощь на 2 станциях"},new[]{"Двигатель уровня 6","Все вагоны уровня 3","18 остановок","Помощь на 5 станциях"}};
            for(int i=0;i<3;i++) { var check=s.StoryChecks(i);string body="Глава "+(i+1)+" · "+s.Content.Chapters[i]+"\n";for(int j=0;j<check.Length;j++)body+=(check[j]?"✓ ":"○ ")+requirements[i][j]+"\n";body+=s.StoryRewards.Contains(s.Content.Chapters[i])?"Награда получена":"Награда: "+Number(s.Content.ChapterRewards[i][0])+" тепла, "+Number(s.Content.ChapterRewards[i][1])+" деталей";Paragraph(body,i==2?215:190,17); }
            Paragraph("Достижения · каждое даёт 20 деталей\n"+string.Join("\n",s.Content.Achievements.Select(a=>(s.Rewards.Contains(a)?"✓ ":"○ ")+a)),300,17);
        }
        void Settings()
        {
            Paragraph("Графика · "+GraphicsProfiles.Names[s.Quality]+"\n"+GraphicsProfiles.Descriptions[s.Quality],100,17);
            var q=CardBox(128);for(int i=0;i<4;i++) { int quality=i;Button(Fixed("Quality "+i,q,14+i%2*236,10+i/2*57,222,49),(i==s.Quality?"✓ ":"")+GraphicsProfiles.Names[i],()=>game.SetQuality(quality),18); }
            ActionCard("Звук: "+(s.Sound?"вкл.":"выкл."),()=> { s.Sound=!s.Sound;game.ApplyAudio();game.Save();Show(4); });
            ActionCard("Экономия батареи: "+(s.Economy?"вкл. · 30 FPS":"выкл. · цель 60 FPS"),()=> { s.Economy=!s.Economy;game.World.Refresh();game.Save();Show(4); });
            ActionCard("Сохранить сейчас",()=> { if(game.Save())Toast("Прогресс сохранён"); });ActionCard("Перенести прогресс / сделать копию",()=>Show(5));
            Paragraph("Поезд за рассветом · Unity "+Application.version+"\nИгра работает без интернета. Автосохранение: каждые 10 секунд и при уходе в фон.\nШрифт DejaVu Sans — лицензия в исходниках.",134,15);
        }
        void ActionCard(string label,Action action) { var r=CardBox(61);Button(At("Action",r,Vector2.zero,Vector2.one,new Vector2(10,6),new Vector2(-10,-6)),label,action,17); }
        void Transfer()
        {
            Paragraph("В старой игре: Настройки → Копировать прогресс. Здесь вставьте JSON и нажмите «Импортировать». Текущий прогресс будет заменён; его копия останется в резервном сохранении.",133,16);
            ActionCard("Копировать текущий прогресс",()=> { game.Save();GUIUtility.systemCopyBuffer=Json.Stringify(s.Snapshot(DawnrailGame.Now));Toast("Сохранение скопировано"); });
            var r=CardBox(180);Image(At("Input background",r,Vector2.zero,Vector2.one,new Vector2(10,8),new Vector2(-10,-8)),Ink);
            var input=r.gameObject.AddComponent<InputField>();input.lineType=InputField.LineType.MultiLineNewline;input.characterLimit=1048576;
            var field=Label(At("JSON",r,Vector2.zero,Vector2.one,new Vector2(17,12),new Vector2(-17,-12)),"",14);field.supportRichText=false;input.textComponent=field;
            var placeholder=Label(At("Placeholder",r,Vector2.zero,Vector2.one,new Vector2(17,12),new Vector2(-17,-12)),"Вставьте сохранение JSON",16,Muted);input.placeholder=placeholder;input.targetGraphic=r.GetComponent<Image>();
            ActionCard("Вставить из буфера",()=>input.text=GUIUtility.systemCopyBuffer);ActionCard("Импортировать прогресс",()=>game.Import(input.text));
        }
        public void ShowEvent()
        {
            var e=s.CurrentEvent;if(e==null)return;panel=6;Open(e.Title);Paragraph(e.Body,145,18);
            for(int i=0;i<e.Choices.Length;i++) { int choice=i;var c=e.Choices[i];var r=CardBox(113);var b=Button(At("Choice",r,Vector2.zero,Vector2.one,new Vector2(10,7),new Vector2(-10,-7)),c.Label+"\n"+s.ChoiceNote(c),()=>game.Choose(choice),18);updates.Add(()=>b.interactable=s.CanChoose(choice)); }
            Paragraph("Поезд ждёт вашего решения. Тепло и детали продолжают производиться.",81,16);Refresh();
        }
        public void Toast(string value) { notice.text=value;toastTime=4;notice.transform.SetAsLastSibling(); }
        public void TapFeedback(double amount) { tapText.text="+"+Number(amount)+" тепла\nНажмите или удерживайте"; }
        void Update() { FitSafeArea();if(toastTime>0) { toastTime-=Time.unscaledDeltaTime;if(toastTime<=0)notice.text=""; }if(Input.GetKeyDown(KeyCode.Escape)) { if(panel>=0)Close();else Show(4); } }
        void FitSafeArea() { if(safe==null)return;Rect area=Screen.safeArea;var size=new Vector2(Screen.width,Screen.height);if(area==oldSafe&&size==oldSize)return;oldSafe=area;oldSize=size;safe.anchorMin=new Vector2(area.x/size.x,area.y/size.y);safe.anchorMax=new Vector2(area.xMax/size.x,area.yMax/size.y); }
        Sprite Rounded()
        {
            var texture=new Texture2D(32,32,TextureFormat.RGBA32,false);texture.name="UI rounded corners";
            for(int y=0;y<32;y++)for(int x=0;x<32;x++) { float cx=Mathf.Clamp(x,8,23),cy=Mathf.Clamp(y,8,23);texture.SetPixel(x,y,new Color(1,1,1,Mathf.Clamp01(9-Vector2.Distance(new Vector2(x,y),new Vector2(cx,cy))))); }texture.Apply();return Sprite.Create(texture,new Rect(0,0,32,32),new Vector2(.5f,.5f),100,0,SpriteMeshType.FullRect,new Vector4(10,10,10,10));
        }
        void OnDestroy() { if(rounded) { Destroy(rounded.texture);Destroy(rounded); } }
    }
}
