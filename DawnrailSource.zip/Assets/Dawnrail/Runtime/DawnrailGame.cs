using System;
using Dawnrail.Core;
using UnityEngine;

namespace Dawnrail.Unity
{
    public sealed class DawnrailGame : MonoBehaviour
    {
        public GameState State { get; private set; }
        public SaveRepository Saves { get; private set; }
        public WorldScene World { get; private set; }
        public GameUI UI { get; private set; }
        AudioSource ambience,tapAudio,eventAudio;float saveTimer,uiTimer,lastTapSound;bool paused;double pausedAt;
        string eventToken="";
        public static double Now { get { return DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()/1000.0; } }
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void StartGame() { if(FindFirstObjectByType<DawnrailGame>()==null)new GameObject("Dawnrail").AddComponent<DawnrailGame>(); }
        void Awake()
        {
            try {
                Screen.orientation=ScreenOrientation.Portrait;Screen.sleepTimeout=SleepTimeout.SystemSetting;
                var content=new GameContent(Resources.Load<TextAsset>("content").text);State=new GameState(content);Saves=new SaveRepository(Application.persistentDataPath,content);
                double away;bool loaded=Saves.Load(State,Now,out away);State.ClaimRewards();
                World=new GameObject("World").AddComponent<WorldScene>();World.Create(State);
                UI=new GameObject("Interface").AddComponent<GameUI>();UI.Create(this);
                ambience=Audio("night",true,.13f);tapAudio=Audio("tap",false,.38f);eventAudio=Audio("station",false,.45f);ApplyAudio();
                if(loaded&&away>30)UI.Toast("Пока вас не было: "+GameUI.Number(away/60)+" мин. Доход добавлен.");
                Save();
            } catch(Exception ex) { Debug.LogException(ex);enabled=false; }
        }
        AudioSource Audio(string name,bool loop,float volume) { var go=new GameObject(name);go.transform.SetParent(transform);var a=go.AddComponent<AudioSource>();a.clip=Resources.Load<AudioClip>("Audio/"+name);a.loop=loop;a.volume=volume;a.playOnAwake=false;return a; }
        void Update()
        {
            if(State==null||paused)return;
            State.Online(Time.unscaledDeltaTime);State.ClaimRewards();
            if(State.Region!=WorldRegion) { WorldRegion=State.Region;World.Refresh(); }
            if(State.Event.Length>0&&State.Event!=eventToken) { eventToken=State.Event;UI.ShowEvent();if(State.Sound)eventAudio.Play(); }
            if(State.Event.Length==0)eventToken="";
            saveTimer+=Time.unscaledDeltaTime;uiTimer+=Time.unscaledDeltaTime;
            if(uiTimer>=.2f) { uiTimer=0;UI.Refresh(); }
            if(saveTimer>=10) { saveTimer=0;Save(); }
        }
        int WorldRegion=-1;
        public void Tap() { double amount=State.Tap();UI.TapFeedback(amount);if(State.Sound&&Time.unscaledTime-lastTapSound>.07f) { lastTapSound=Time.unscaledTime;tapAudio.PlayOneShot(tapAudio.clip); } }
        public void Buy(string key) { if(!State.Buy(key))return;State.ClaimRewards();if(key!="fire"&&key!="crew")World.RebuildTrain();Save();UI.RebuildPanel();UI.Refresh(); }
        public void Assign(string key,int change) { if(!State.Assign(key,change))return;World.RebuildTrain();Save();UI.RebuildPanel(); }
        public void Choose(int choice) { if(!State.Choose(choice))return;State.ClaimRewards();World.Refresh();Save();UI.Close();UI.Toast(State.LastChoice); }
        public void SetQuality(int quality) { State.Quality=quality;World.Refresh(true);Save();UI.RebuildPanel(); }
        public void ApplyAudio() { if(ambience==null)return;if(State.Sound) { if(!ambience.isPlaying)ambience.Play(); } else { ambience.Stop();tapAudio.Stop();eventAudio.Stop(); } }
        public bool Save() { bool ok=Saves.Save(State,Now);if(!ok&&UI!=null)UI.Toast("Не удалось сохранить: "+Saves.Error);return ok; }
        public bool Import(string text) { if(!Saves.Import(text,State,Now)) { UI.Toast(Saves.Error);return false; }World.Refresh(true);ApplyAudio();UI.Close();UI.Refresh();UI.Toast("Прогресс перенесён");return true; }
        void OnApplicationPause(bool value)
        {
            if(State==null)return;
            if(value&&!paused) { paused=true;pausedAt=Now;Save(); }
            else if(!value&&paused) { State.Offline(Math.Max(0,Now-pausedAt));State.ClaimRewards();State.Velocity=0;paused=false;World.Refresh();Save();UI.Refresh(); }
        }
        void OnApplicationQuit() { if(State!=null)Save(); }
        void OnDestroy() { if(World)Destroy(World.gameObject);if(UI)Destroy(UI.gameObject); }
    }
}
