using UnityEngine;
using UnityEngine.Rendering;

namespace Dawnrail.Unity
{
    public static class GraphicsProfiles
    {
        public static readonly string[] Names={"Низкая","Средняя","Высокая","Ультра"};
        public static readonly int[] Trees={14,28,48,76},Particles={0,30,70,120};
        public static readonly string[] Descriptions={"Без теней и снега, редкое окружение, MSAA выключено","Короткие тени, MSAA 2×, больше деревьев","Мягкие тени, MSAA 4×, густой лес и снег","Тени 50 м, MSAA 8×, цветы, густое окружение и больше пара"};
        public static void Apply(int quality,bool economy,Light sun)
        {
            quality=Mathf.Clamp(quality,0,3); QualitySettings.SetQualityLevel(quality,true);
            var asset=Resources.Load<RenderPipelineAsset>("Quality/"+quality);
            if(asset==null)throw new System.InvalidOperationException("URP assets missing. Run Dawnrail > Prepare project.");
            QualitySettings.renderPipeline=asset;
            Application.targetFrameRate=economy?30:60; QualitySettings.vSyncCount=0;
            sun.shadows=quality==0?LightShadows.None:LightShadows.Soft;
        }
    }
}
