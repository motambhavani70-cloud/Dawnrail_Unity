using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace Dawnrail.Unity
{
    // Several hundred sleepers, leaves and joints become instanced mesh batches.
    // Transform pivots remain available for articulation and wagon cutaways.
    public sealed class InstanceBatch
    {
        sealed class Group { public Mesh Mesh;public Material Material;public readonly List<Transform> Transforms=new List<Transform>(); }
        readonly List<Group> groups=new List<Group>();readonly Matrix4x4[] matrices=new Matrix4x4[1023];
        public void Capture(Transform root)
        {
            groups.Clear();if(!SystemInfo.supportsInstancing)return;
            var lookup=new Dictionary<string,Group>();
            foreach(var renderer in root.GetComponentsInChildren<MeshRenderer>(true)) {
                var filter=renderer.GetComponent<MeshFilter>();if(filter==null||filter.sharedMesh==null||renderer.sharedMaterial==null)continue;
                var mat=renderer.sharedMaterial;mat.enableInstancing=true;string key=filter.sharedMesh.GetInstanceID()+":"+mat.GetInstanceID();Group group;
                if(!lookup.TryGetValue(key,out group)) { group=new Group{Mesh=filter.sharedMesh,Material=mat};lookup.Add(key,group);groups.Add(group); }
                group.Transforms.Add(renderer.transform);renderer.enabled=false;
            }
        }
        public void Draw(Camera camera)
        {
            foreach(var group in groups) {
                int count=0;foreach(var transform in group.Transforms) {
                    if(transform==null||!transform.gameObject.activeInHierarchy)continue;matrices[count++]=transform.localToWorldMatrix;
                    if(count==1023) { Submit(group,count,camera);count=0; }
                }if(count>0)Submit(group,count,camera);
            }
        }
        void Submit(Group group,int count,Camera camera) { Graphics.DrawMeshInstanced(group.Mesh,0,group.Material,matrices,count,null,ShadowCastingMode.On,true,0,camera); }
    }
}
