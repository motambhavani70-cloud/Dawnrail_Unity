using System;
using System.Collections.Generic;
using Dawnrail.Core;
using UnityEngine;

namespace Dawnrail.Unity
{
    public sealed class TrainVisual
    {
        public sealed class Vehicle
        {
            public string Key; public double Arc; public Transform Frame,Body,Roof,Wall;
            public readonly List<Transform> Wheels=new List<Transform>(); public float WheelRadius; public double SpringY,SpringV;
        }
        readonly Geometry g; readonly Transform root; readonly GameState state;
        readonly List<Vehicle> vehicles=new List<Vehicle>(); readonly List<Transform> couplings=new List<Transform>();
        public IList<Vehicle> Vehicles { get { return vehicles; } }
        public int Focus=1;
        static readonly Color Steel=new Color(.18f,.24f,.25f),Brass=new Color(.79f,.56f,.25f),Wood=new Color(.42f,.23f,.12f),Ivory=new Color(.84f,.78f,.61f);
        public TrainVisual(Geometry geo,Transform parent,GameState s) { g=geo;root=parent;state=s; Rebuild(); }
        public void Rebuild()
        {
            foreach(Transform child in root) { child.gameObject.SetActive(false); UnityEngine.Object.Destroy(child.gameObject); }
            vehicles.Clear(); couplings.Clear();
            BuildEngine(); BuildWagon("home",.65);
            if(state.Wagons["workshop"]>0)BuildWagon("workshop",4.85);
            if(state.Wagons["garden"]>0)BuildWagon("garden",state.Wagons["workshop"]>0?9.05:4.85);
            for(int i=1;i<vehicles.Count;i++)couplings.Add(g.Box("Flexible coupling",root,Vector3.zero,new Vector3(1,.1f,.15f),Steel,.025f,.6f));
            Focus=Mathf.Clamp(Focus,0,vehicles.Count-1); SetFocus(Focus);
        }
        Vehicle Frame(string key,double arc,float radius,float axleOffset)
        {
            var v=new Vehicle { Key=key,Arc=arc,WheelRadius=radius,Frame=g.Node(key,root,Vector3.zero) };
            v.Body=g.Node("Suspension",v.Frame,Vector3.zero);
            g.Box("Chassis",v.Frame,new Vector3(0,.85f,0),new Vector3(3.9f,.2f,1.55f),Steel,.07f,.6f);
            for(int axle=-1;axle<=1;axle+=2) {
                g.Cylinder("Axle",v.Frame,new Vector3(axle*axleOffset,.21f+radius,0),.07f,1.75f,Steel,new Vector3(90,0,0),.7f);
                for(int side=-1;side<=1;side+=2) {
                    var wheel=g.Node("Rolling wheel",v.Frame,new Vector3(axle*axleOffset,.21f+radius,side*.78f)); v.Wheels.Add(wheel);
                    g.Cylinder("Tyre",wheel,Vector3.zero,radius,.13f,Steel,new Vector3(90,0,0),.8f);
                    g.Cylinder("Inset",wheel,new Vector3(0,0,side*.075f),radius*.8f,.026f,new Color(.12f,.16f,.16f),new Vector3(90,0,0),.5f);
                    for(int spoke=0;spoke<6;spoke++) { float a=spoke*Mathf.PI/3; g.Beam("Spoke",wheel,new Vector3(0,0,side*.095f),new Vector3(Mathf.Cos(a)*radius*.8f,Mathf.Sin(a)*radius*.8f,side*.095f),.035f,Brass); }
                    g.Cylinder("Hub",wheel,new Vector3(0,0,side*.105f),radius*.18f,.05f,Brass,new Vector3(90,0,0),.7f);
                }
            }
            vehicles.Add(v);return v;
        }
        void BuildEngine()
        {
            var v=Frame("engine",-3.65,.48f,1.25f); int level=state.Engine;
            g.Cylinder("Boiler",v.Body,new Vector3(-.65f,1.49f,0),.58f,2.25f,new Color(.19f,.32f,.29f),new Vector3(0,0,90),.55f);
            g.Cylinder("Smokebox",v.Body,new Vector3(-1.84f,1.49f,0),.52f,.15f,Steel,new Vector3(0,0,90),.8f);
            foreach(float x in new[]{-1.35f,-.4f})g.Cylinder("Boiler band",v.Body,new Vector3(x,1.49f,0),.588f,.055f,Brass,new Vector3(0,0,90),.7f);
            g.Cylinder("Chimney",v.Body,new Vector3(-1.08f,2.22f,0),.17f,.62f,Steel,Vector3.zero,.8f);g.Cylinder("Chimney lip",v.Body,new Vector3(-1.08f,2.54f,0),.21f,.075f,Brass,Vector3.zero,.7f);
            g.Cylinder("Steam dome",v.Body,new Vector3(-.15f,2.08f,0),.19f,.35f,Brass,Vector3.zero,.6f);
            g.Box("Cab rear",v.Body,new Vector3(1.7f,1.82f,0),new Vector3(.12f,1.72f,1.72f),new Color(.25f,.38f,.3f),.06f);
            g.Box("Cab far wall",v.Body,new Vector3(1,1.42f,-.8f),new Vector3(1.4f,.86f,.1f),new Color(.25f,.38f,.3f));
            for(int side=-1;side<=1;side+=2)for(int edge=-1;edge<=1;edge+=2)g.Box("Cab pillar",v.Body,new Vector3(1+edge*.7f,2.14f,side*.8f),new Vector3(.08f,1.05f,.08f),Brass,.03f,.4f);
            v.Roof=g.Box("Cab roof",v.Body,new Vector3(1,2.76f,0),new Vector3(1.7f,.16f,1.95f),new Color(.22f,.27f,.25f),.075f);
            g.Box("Firebox",v.Body,new Vector3(.43f,1.42f,0),new Vector3(.22f,.63f,1.1f),Steel,.1f,.6f);
            g.Cylinder("Star furnace",v.Body,new Vector3(.56f,1.48f,0),.22f,.025f,new Color(1,.43f,.09f),new Vector3(0,0,90));
            g.Sphere("Headlight",v.Body,new Vector3(-1.94f,1.75f,0),Vector3.one*.22f,new Color(1,.81f,.43f));
            for(int i=0;i<5;i++)g.Beam("Cowcatcher",v.Frame,new Vector3(-1.92f,.87f,(i-2)*.3f),new Vector3(-2.2f,.31f,(i-2)*.34f),.07f,Brass);
            if(level>=2)for(int i=0;i<2;i++)g.Cylinder("Gauge",v.Body,new Vector3(.56f,1.91f,(i-.5f)*.32f),.085f,.04f,Ivory,new Vector3(0,0,90));
            if(level>=3)for(int side=-1;side<=1;side+=2)g.Box("Cab stripe",v.Body,new Vector3(1,1.46f,side*.81f),new Vector3(1.3f,.065f,.025f),Brass,.01f);
            if(level>=5)g.Cylinder("Extra pipe",v.Body,new Vector3(-.42f,2.4f,-.22f),.085f,.55f,Brass,Vector3.zero,.5f);
            if(level>=6)g.Box("Roof trim",v.Roof,new Vector3(0,.1f,0),new Vector3(1.57f,.055f,1.79f),Brass,.025f);
            if(level>=7)Lamp(v.Body,new Vector3(1.1f,2.45f,.65f));
            if(level>=10)g.Box("Boiler armour",v.Body,new Vector3(-.65f,1.2f,0),new Vector3(2.2f,.13f,1.31f),Brass,.065f,.7f);
            Person(v.Body,new Vector3(1.05f,1.01f,.15f),"driver",new Color(.28f,.4f,.53f),0,-90);
            if(state.Jobs["stoker"]>0)Person(v.Body,new Vector3(.8f,1.01f,-.38f),"craft",new Color(.56f,.32f,.19f),8,-90);
        }
        void BuildWagon(string key,double arc)
        {
            int level=state.Wagons[key]; var v=Frame(key,arc,.36f,1.12f);
            Color paint=key=="home"?new Color(.49f,.22f,.16f):key=="workshop"?new Color(.16f,.3f,.38f):new Color(.29f,.42f,.24f);
            g.Box("Floor",v.Body,new Vector3(0,1.01f,0),new Vector3(3.85f,.14f,1.75f),Wood,.04f);
            g.Box("Far wall",v.Body,new Vector3(0,1.46f,-.87f),new Vector3(3.8f,.8f,.11f),paint,.04f);
            v.Wall=g.Node("Cutaway near wall",v.Body,Vector3.zero);g.Box("Near wall",v.Wall,new Vector3(0,1.46f,.87f),new Vector3(3.8f,.8f,.11f),paint,.04f);
            foreach(Transform side in new[]{v.Body,v.Wall}) {
                float z=side==v.Body?-.87f:.87f;
                for(int i=0;i<4;i++) { float x=-1.43f+i*.96f;g.Box("Window frame",side,new Vector3(x,2.17f,z),new Vector3(.84f,.67f,.09f),Brass,.05f);g.Box("Window glass",side,new Vector3(x,2.17f,z+(z>0?.055f:-.055f)),new Vector3(.72f,.54f,.025f),new Color(.45f,.67f,.64f),.045f,.4f); }
            }
            for(int side=-1;side<=1;side+=2)g.Box("End wall",v.Body,new Vector3(side*1.85f,1.93f,0),new Vector3(.1f,1.75f,1.72f),paint,.05f);
            v.Roof=g.Box("Rounded roof",v.Body,new Vector3(0,2.89f,0),new Vector3(4.02f,.32f,1.98f),new Color(.2f,.24f,.22f),.15f);
            g.Box("Gold trim",v.Body,new Vector3(0,1.1f,-.935f),new Vector3(3.68f,.045f,.045f),Brass,.016f);
            if(level>=3) { var extra=g.Box("Roof upgrade",v.Roof,new Vector3(0,.31f,0),new Vector3(1.42f,.36f,1.14f),key=="garden"?new Color(.45f,.68f,.59f):paint,.15f);g.Box("Roof trim",extra,new Vector3(0,.19f,0),new Vector3(1.57f,.06f,1.27f),Brass,.03f); }
            if(key=="home") {
                g.Box("Sofa",v.Body,new Vector3(-1.15f,1.29f,-.35f),new Vector3(.92f,.42f,.52f),new Color(.66f,.46f,.25f),.12f);
                g.Box("Table",v.Body,new Vector3(-.45f,1.65f,-.12f),new Vector3(.54f,.08f,.63f),Wood,.04f);g.Cylinder("Table leg",v.Body,new Vector3(-.45f,1.33f,-.12f),.055f,.58f,Brass,Vector3.zero);
                if(level>=2) { g.Box("Bookshelf",v.Body,new Vector3(1.35f,1.8f,-.54f),new Vector3(.54f,1.25f,.27f),Wood,.02f);for(int i=0;i<5;i++)g.Box("Book",v.Body,new Vector3(1.16f+i*.09f,2.12f,-.34f),new Vector3(.07f,.25f,.15f),new Color(.3f+.08f*i,.48f-.05f*i,.32f),.012f); }
                if(level>=5)g.Cylinder("Teapot",v.Body,new Vector3(-.45f,1.82f,-.12f),.09f,.22f,Ivory,Vector3.zero);
                if(level>=6)g.Cylinder("Wall clock",v.Body,new Vector3(.3f,2.42f,-.77f),.16f,.07f,Ivory,new Vector3(90,0,0));
                if(level>=10) { g.Box("Woven rug",v.Body,new Vector3(.4f,1.095f,.17f),new Vector3(1.35f,.025f,.92f),new Color(.7f,.31f,.2f),.01f);Plant(v.Body,new Vector3(1.5f,1.18f,.49f),true); }
                Person(v.Body,new Vector3(-1.1f,1.09f,-.18f),"read",new Color(.45f,.31f,.57f),1,0);Person(v.Body,new Vector3(.45f,1.09f,.06f),level>=5?"tea":"walk",new Color(.31f,.49f,.53f),2,0);
            } else if(key=="workshop") {
                g.Box("Workbench",v.Body,new Vector3(0,1.64f,-.38f),new Vector3(2.35f,.12f,.65f),Wood,.03f);
                for(int i=-1;i<=1;i+=2)g.Box("Table legs",v.Body,new Vector3(i*.9f,1.31f,-.38f),new Vector3(.12f,.53f,.46f),Steel,.025f);
                if(level>=2)for(int i=0;i<5;i++)g.Beam("Hanging tools",v.Body,new Vector3(-.8f+i*.35f,2.06f,-.68f),new Vector3(-.8f+i*.35f,2.32f,-.68f),.045f,Brass);
                if(level>=5)g.Box("Bench press",v.Body,new Vector3(.7f,1.88f,-.37f),new Vector3(.35f,.38f,.33f),Steel,.06f,.6f);
                if(level>=6)Lamp(v.Body,new Vector3(-.85f,2.55f,-.48f));
                if(level>=10)g.Box("Parts cabinet",v.Body,new Vector3(1.43f,1.57f,-.26f),new Vector3(.48f,.91f,.81f),paint,.05f,.4f);
                Person(v.Body,new Vector3(-.3f,1.09f,.25f),"craft",new Color(.59f,.38f,.23f),3,180); if(state.Jobs["mechanic"]>1)Person(v.Body,new Vector3(-1.2f,1.09f,.12f),"craft",new Color(.36f,.46f,.48f),4,180);
            } else {
                for(int i=0;i<5;i++)Plant(v.Body,new Vector3(-1.32f+i*.6f,1.23f,-.42f),level>=2);
                if(level>=5)for(int i=0;i<5;i++)g.Sphere("Fruit",v.Body,new Vector3(-1.32f+i*.6f,1.77f,-.3f),Vector3.one*.13f,new Color(.94f,.35f,.11f));
                if(level>=6)Lamp(v.Body,new Vector3(.9f,2.58f,-.4f)); if(level>=10) { g.Box("Seedling shelf",v.Body,new Vector3(1.35f,1.51f,.3f),new Vector3(.42f,.06f,.7f),Wood);Plant(v.Body,new Vector3(1.35f,1.63f,.25f),true); }
                Person(v.Body,new Vector3(0,1.09f,.25f),"water",new Color(.37f,.5f,.25f),5,0);if(state.Jobs["gardener"]>1)Person(v.Body,new Vector3(1.05f,1.09f,-.07f),"read",new Color(.32f,.44f,.35f),6,0);
            }
        }
        void Plant(Transform p,Vector3 pos,bool flowers)
        {
            g.Cylinder("Terracotta pot",p,pos,.14f,.26f,new Color(.57f,.29f,.17f),Vector3.zero);
            g.Cylinder("Stem",p,pos+Vector3.up*.33f,.018f,.4f,new Color(.28f,.41f,.16f),Vector3.zero);
            for(int i=-1;i<=1;i++)g.Sphere("Leaf",p,pos+new Vector3(i*.08f,.35f+Mathf.Abs(i)*.06f,0),new Vector3(.2f,.1f,.15f),new Color(.43f,.59f,.2f));
            if(flowers)g.Sphere("Flower",p,pos+Vector3.up*.55f,Vector3.one*.15f,new Color(.96f,.63f,.25f));
        }
        void Person(Transform p,Vector3 pos,string task,Color color,int seed,float yaw) { var t=g.Node("Resident "+task,p,pos);t.localRotation=Quaternion.Euler(0,yaw,0);t.gameObject.AddComponent<ResidentActivity>().Create(g,task,color,seed); }
        void Lamp(Transform p,Vector3 pos) { var t=g.Sphere("Warm lamp",p,pos,Vector3.one*.15f,new Color(1,.75f,.35f));if(state.Quality>=2) { var light=t.gameObject.AddComponent<Light>();light.type=LightType.Point;light.range=2.5f;light.intensity=.8f;light.color=new Color(1,.7f,.4f);light.shadows=LightShadows.None; } }
        public void SetFocus(int index) { Focus=Mathf.Clamp(index,0,vehicles.Count-1);for(int i=0;i<vehicles.Count;i++) { var v=vehicles[i];if(v.Roof)v.Roof.gameObject.SetActive(i!=Focus);if(v.Wall)v.Wall.gameObject.SetActive(i!=Focus); } }
        public void Tick(float dt,bool curved)
        {
            foreach(var v in vehicles) {
                Vector3 p=Pose(v.Arc,curved),a=Pose(v.Arc-1.12,curved),b=Pose(v.Arc+1.12,curved);
                v.Frame.localPosition=p;v.Frame.localRotation=Quaternion.FromToRotation(Vector3.right,b-a);
                double target=state.Velocity>.01?.016*Math.Sin(state.Distance*5+v.Arc):0;
                var spring=RailMotion.Spring(v.SpringY,v.SpringV,target,11,dt);v.SpringY=spring.Distance;v.SpringV=spring.Velocity;
                v.Body.localPosition=new Vector3(0,(float)v.SpringY,0);
                foreach(var wheel in v.Wheels)wheel.localRotation=Quaternion.Euler(0,0,(float)(RailPath.Mod(state.Distance/v.WheelRadius,Math.PI*2)*Mathf.Rad2Deg));
            }
            for(int i=1;i<vehicles.Count;i++) {
                Vector3 a=vehicles[i-1].Frame.TransformPoint(new Vector3(2.03f,.87f,0)),b=vehicles[i].Frame.TransformPoint(new Vector3(-2.03f,.87f,0));
                var t=couplings[i-1];t.position=(a+b)*.5f;t.rotation=Quaternion.FromToRotation(Vector3.right,b-a);t.localScale=new Vector3((b-a).magnitude,1,1);
            }
        }
        Vector3 Pose(double arc,bool curved) { var p=RailPath.Pose(arc,state.Distance,curved);return new Vector3((float)p.X,0,(float)p.Z); }
        public Vector3 FocusPosition { get { return vehicles[Focus].Frame.position+Vector3.up*1.5f; } }
        public string FocusKey { get { return vehicles[Focus].Key; } }
    }
}
