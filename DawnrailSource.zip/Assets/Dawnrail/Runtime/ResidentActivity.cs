using UnityEngine;

namespace Dawnrail.Unity
{
    // Articulated local joints, deterministic work cycles; no Humanoid claim.
    public sealed class ResidentActivity : MonoBehaviour
    {
        public string Activity;
        public float WalkRange=.55f;
        Transform head,leftArm,rightArm,leftLeg,rightLeg,tool;
        Vector3 home; float phase,baseYaw;
        public void Create(Geometry g,string activity,Color coat,int seed)
        {
            Activity=activity;home=transform.localPosition;phase=seed*.73f;baseYaw=transform.localEulerAngles.y;
            g.Sphere("Coat",transform,new Vector3(0,.65f,0),new Vector3(.34f,.55f,.26f),coat);
            g.Box("Belt",transform,new Vector3(0,.46f,0),new Vector3(.29f,.04f,.24f),new Color(.18f,.15f,.13f),.02f);
            head=g.Node("Head",transform,new Vector3(0,1.05f,0));
            g.Sphere("Face",head,Vector3.zero,new Vector3(.25f,.29f,.23f),new Color(.85f,.62f,.43f));
            g.Sphere("Hair",head,new Vector3(0,.09f,-.025f),new Vector3(.26f,.15f,.23f),new Color(.18f,.12f,.09f));
            for(int sign=-1;sign<=1;sign+=2)g.Sphere("Eye",head,new Vector3(sign*.052f,.025f,.108f),Vector3.one*.026f,new Color(.09f,.07f,.06f));
            g.Sphere("Nose",head,new Vector3(0,-.025f,.13f),new Vector3(.04f,.06f,.06f),new Color(.91f,.65f,.45f));
            g.Box("Scarf",transform,new Vector3(0,.87f,.01f),new Vector3(.27f,.095f,.26f),new Color(.94f,.7f,.32f),.04f);
            leftArm=g.Limb("Left arm",transform,new Vector3(-.19f,.85f,0),.36f,.065f,coat); rightArm=g.Limb("Right arm",transform,new Vector3(.19f,.85f,0),.36f,.065f,coat);
            g.Sphere("Hand",leftArm,new Vector3(0,-.36f,0),Vector3.one*.11f,new Color(.85f,.62f,.43f)); g.Sphere("Hand",rightArm,new Vector3(0,-.36f,0),Vector3.one*.11f,new Color(.85f,.62f,.43f));
            leftLeg=g.Limb("Left leg",transform,new Vector3(-.095f,.42f,0),.33f,.065f,new Color(.19f,.25f,.27f)); rightLeg=g.Limb("Right leg",transform,new Vector3(.095f,.42f,0),.33f,.065f,new Color(.19f,.25f,.27f));
            foreach(var leg in new[]{leftLeg,rightLeg})g.Box("Boot",leg,new Vector3(0,-.34f,.045f),new Vector3(.13f,.09f,.2f),new Color(.17f,.12f,.1f),.035f);
            if(activity=="read") { tool=g.Box("Open book",rightArm,new Vector3(-.12f,-.3f,.04f),new Vector3(.27f,.035f,.22f),new Color(.87f,.79f,.58f),.01f); g.Box("Book spine",tool,Vector3.zero,new Vector3(.018f,.04f,.22f),coat,.005f); }
            if(activity=="tea")tool=g.Cylinder("Tea cup",rightArm,new Vector3(0,-.32f,.06f),.07f,.12f,new Color(.91f,.87f,.76f),Vector3.zero);
            if(activity=="craft") { tool=g.Cylinder("Hammer handle",rightArm,new Vector3(0,-.4f,0),.022f,.24f,new Color(.51f,.31f,.17f),Vector3.zero); g.Box("Hammer head",tool,new Vector3(0,-.1f,0),new Vector3(.15f,.05f,.06f),new Color(.45f,.48f,.49f),.016f,.7f); }
            if(activity=="stoke") { tool=g.Cylinder("Shovel handle",rightArm,new Vector3(0,-.46f,.02f),.025f,.47f,new Color(.51f,.31f,.17f),Vector3.zero);g.Box("Shovel blade",tool,new Vector3(0,-.28f,0),new Vector3(.18f,.18f,.04f),new Color(.31f,.35f,.34f),.035f,.6f); }
            if(activity=="water") { tool=g.Cylinder("Watering can",rightArm,new Vector3(0,-.35f,.05f),.095f,.14f,new Color(.34f,.63f,.53f),Vector3.zero,.4f); g.Beam("Spout",tool,new Vector3(.06f,0,0),new Vector3(.18f,.09f,0),.035f,new Color(.34f,.63f,.53f)); }
        }
        void Update() { Tick(Time.time); }
        public void Tick(float time)
        {
            float t=time+phase,s=Mathf.Sin(t*2),walking=0;
            transform.localPosition=home+Vector3.up*(.006f*Mathf.Sin(t*1.4f));
            head.localRotation=Quaternion.Euler(2*Mathf.Sin(t*.8f),9*Mathf.Sin(t*.4f),0);
            leftArm.localRotation=Quaternion.Euler(5*s,0,-8); rightArm.localRotation=Quaternion.Euler(-5*s,0,8);
            if(Activity=="read") { leftArm.localRotation=Quaternion.Euler(-65,0,-12);rightArm.localRotation=Quaternion.Euler(-70+3*s,0,12);head.localRotation=Quaternion.Euler(14,4*Mathf.Sin(t*.7f),0); }
            if(Activity=="tea")rightArm.localRotation=Quaternion.Euler(-40-45*Mathf.Pow(Mathf.Max(0,Mathf.Sin(t*.8f)),3),0,12);
            if(Activity=="craft") { rightArm.localRotation=Quaternion.Euler(-55-35*Mathf.Max(0,Mathf.Sin(t*3)),0,10);leftArm.localRotation=Quaternion.Euler(-55,0,-8); head.localRotation=Quaternion.Euler(12,0,0); }
            if(Activity=="stoke") { rightArm.localRotation=Quaternion.Euler(-38-32*Mathf.Max(0,Mathf.Sin(t*1.6f)),0,10);leftArm.localRotation=Quaternion.Euler(-43-20*Mathf.Max(0,Mathf.Sin(t*1.6f)),0,-10);head.localRotation=Quaternion.Euler(10,0,0); }
            if(Activity=="driver") { leftArm.localRotation=Quaternion.Euler(-40,0,-14); rightArm.localRotation=Quaternion.Euler(-38-8*s,0,10); }
            if(Activity=="water"||Activity=="walk") {
                float cycle=Mathf.Repeat(t,16),x=cycle<4?-WalkRange:cycle<8?Mathf.Lerp(-WalkRange,WalkRange,(cycle-4)/4):cycle<12?WalkRange:Mathf.Lerp(WalkRange,-WalkRange,(cycle-12)/4);
                walking=(cycle>=4&&cycle<8||cycle>=12)?1:0;
                transform.localPosition=home+new Vector3(x,walking*.012f*Mathf.Abs(Mathf.Sin(t*6)),0);transform.localRotation=Quaternion.Euler(0,baseYaw+(walking>0?(cycle<8?90:-90):0),0);
                if(Activity=="water")rightArm.localRotation=Quaternion.Euler(walking>0?-20:-55-8*s,0,walking>0?5:28);
            }
            leftLeg.localRotation=Quaternion.Euler(24*Mathf.Sin(t*6)*walking,0,0);rightLeg.localRotation=Quaternion.Euler(-24*Mathf.Sin(t*6)*walking,0,0);
        }
    }
}
