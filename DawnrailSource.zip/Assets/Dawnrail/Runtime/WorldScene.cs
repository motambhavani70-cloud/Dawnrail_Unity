using System.Collections.Generic;
using Dawnrail.Core;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Dawnrail.Unity
{
    public sealed class WorldScene : MonoBehaviour
    {
        sealed class RailPart { public float Arc;public Transform Tie,Left,Right; }
        sealed class Scenery { public Transform Root;public float Arc,Z; }
        readonly List<RailPart> rail=new List<RailPart>(); readonly List<Scenery> scenery=new List<Scenery>();
        readonly InstanceBatch batches=new InstanceBatch();
        GameState state;Geometry geometry;Transform trainRoot,terrainRoot;Light sun;Material sky;
        ParticleSystem smoke,snow; Camera cameraView;int region=-1,quality=-1;float cameraDistance=12;
        public TrainVisual Train { get; private set; }
        public bool Curved { get { return state.Region!=2&&state.Region!=4; } }
        static Color Hex(string s) { Color c;ColorUtility.TryParseHtmlString("#"+s,out c);return c; }
        static readonly string[] Ground={"d1ded7","4b6540","69715e","7e6454","467a74","bebcc0","c89562"};
        static readonly string[] Horizon={"bed5d1","adbd8d","baa997","d6a8a0","70b2b1","cbb5c7","edc194"};
        static readonly string[] Zenith={"577383","42634d","625b69","684b66","356879","5d526c","78557a"};
        public void Create(GameState game)
        {
            state=game;geometry=new Geometry();trainRoot=geometry.Node("Train",transform,Vector3.zero);terrainRoot=geometry.Node("Biome",transform,Vector3.zero);
            sun=geometry.Node("Sun",transform,Vector3.zero).gameObject.AddComponent<Light>();sun.type=LightType.Directional;sun.intensity=1.7f;sun.color=new Color(1,.91f,.77f);sun.transform.rotation=Quaternion.Euler(43,-36,0);
            RenderSettings.ambientMode=AmbientMode.Trilight;RenderSettings.ambientSkyColor=new Color(.43f,.53f,.57f);RenderSettings.ambientEquatorColor=new Color(.47f,.46f,.39f);RenderSettings.ambientGroundColor=new Color(.22f,.25f,.23f);
            RenderSettings.fog=true;RenderSettings.fogMode=FogMode.ExponentialSquared;RenderSettings.fogDensity=.012f;
            sky=new Material(Resources.Load<Shader>("DawnSky"));RenderSettings.skybox=sky;
            cameraView=geometry.Node("Camera",transform,Vector3.zero).gameObject.AddComponent<Camera>();cameraView.tag="MainCamera";cameraView.fieldOfView=38;cameraView.nearClipPlane=.1f;cameraView.farClipPlane=130;cameraView.allowHDR=true;
            var additional=cameraView.GetUniversalAdditionalCameraData();additional.renderPostProcessing=true;
            var volume=geometry.Node("Post processing",transform,Vector3.zero).gameObject.AddComponent<Volume>();volume.isGlobal=true;volume.sharedProfile=Resources.Load<VolumeProfile>("DawnVolume");
            for(float arc=-42;arc<=42;arc+=.7f) {
                var tie=geometry.Box("Sleeper",transform,Vector3.zero,new Vector3(.15f,.12f,2.07f),Hex("554332"));
                var left=geometry.Box("Rail left",transform,Vector3.zero,new Vector3(.72f,.11f,.095f),Hex("a7afab"),.025f,.8f);
                var right=geometry.Box("Rail right",transform,Vector3.zero,new Vector3(.72f,.11f,.095f),Hex("a7afab"),.025f,.8f);
                rail.Add(new RailPart { Arc=arc,Tie=tie,Left=left,Right=right });
            }
            // Steam follows the locomotive but must survive a train rebuild.
            smoke=Particles("Steam",transform,Hex("dfe8de"),.28f,1.7f);snow=Particles("Snow",transform,Hex("fff5e1"),.04f,7);
            Refresh(true);cameraView.transform.position=Train.FocusPosition+new Vector3(-7,8,12);cameraView.transform.LookAt(Train.FocusPosition);
        }
        ParticleSystem Particles(string name,Transform parent,Color color,float size,float lifetime)
        {
            var t=geometry.Node(name,parent,Vector3.zero);var ps=t.gameObject.AddComponent<ParticleSystem>();var main=ps.main;main.startColor=color;main.startSize=size;main.startLifetime=lifetime;main.startSpeed=.65f;main.maxParticles=160;main.simulationSpace=ParticleSystemSimulationSpace.World;
            var shape=ps.shape;shape.shapeType=ParticleSystemShapeType.Box;shape.scale=name=="Snow"?new Vector3(26,1,20):Vector3.one*.2f;
            var velocity=ps.velocityOverLifetime;velocity.enabled=true;velocity.y=name=="Snow"?-1:.6f;velocity.x=.2f;
            var renderer=ps.GetComponent<ParticleSystemRenderer>();renderer.sharedMaterial=Resources.Load<Material>("SteamMaterial");return ps;
        }
        public void Refresh(bool force=false)
        {
            bool changed=force||quality!=state.Quality||region!=state.Region;
            GraphicsProfiles.Apply(state.Quality,state.Economy,sun);
            cameraView.GetUniversalAdditionalCameraData().renderPostProcessing=state.Quality>=2;
            var snowEmission=snow.emission;snowEmission.rateOverTime=state.Economy?0:GraphicsProfiles.Particles[state.Quality];
            var steamEmission=smoke.emission;steamEmission.rateOverTime=state.Economy||state.Quality==0?0:state.Quality*7;
            snow.gameObject.SetActive((state.Region==0||state.Region==5)&&!state.Economy&&state.Quality>0);
            if(!changed) { if(Train!=null&&Train.NeedsRefresh)RebuildTrain();return; }
            region=state.Region;quality=state.Quality;geometry.Detail=quality;
            if(Train==null)Train=new TrainVisual(geometry,trainRoot,state);else Train.Rebuild();
            for(int i=terrainRoot.childCount-1;i>=0;i--) { var child=terrainRoot.GetChild(i);child.gameObject.SetActive(false);Geometry.Release(child.gameObject); }scenery.Clear();
            Color ground=Hex(Ground[region]),horizon=Hex(Horizon[region]);sky.SetColor("_Top",Hex(Zenith[region]));sky.SetColor("_Horizon",horizon);RenderSettings.fogColor=horizon;
            sun.color=region==6?new Color(1,.68f,.37f):region==0?new Color(.9f,.96f,1):new Color(1,.89f,.7f);
            if(region==2||region==4) {
                geometry.Box("Water",terrainRoot,new Vector3(0,-2.65f,0),new Vector3(160,.3f,140),Hex("456f73"),.13f,.4f);
                geometry.Box("Stone bridge deck",terrainRoot,new Vector3(0,-.23f,0),new Vector3(100,.5f,2.6f),Hex("b2a18a"),.12f);
                for(int i=-10;i<=10;i++) { geometry.Box("Bridge pier",terrainRoot,new Vector3(i*4,-2.05f,0),new Vector3(.72f,3.4f,2.45f),Hex("a3947d"),.2f); if(quality>=2)for(int side=-1;side<=1;side+=2)geometry.Box("Parapet",terrainRoot,new Vector3(i*4,-.01f,side*1.32f),new Vector3(3.55f,.26f,.17f),Hex("b9a78e"),.08f); }
            } else geometry.Box("Terrain",terrainRoot,new Vector3(0,-.37f,0),new Vector3(160,.55f,140),ground,.25f);
            var random=new System.Random(400+region);
            for(int i=0;i<GraphicsProfiles.Trees[quality];i++) {
                float arc=(float)random.NextDouble()*80-40,z=(i%2==0?1:-1)*(3.5f+(float)random.NextDouble()*20);
                var node=geometry.Node("Scenery "+i,terrainRoot,Vector3.zero);scenery.Add(new Scenery{Root=node,Arc=arc,Z=z});
                if(region==3&&i%3!=0)Building(node,random);else Tree(node,random,region==0||region==5);
            }
            for(int i=0;i<8;i++) {
                var node=geometry.Node("Distant hill",terrainRoot,new Vector3((i-4)*16,-1,-27-i%2*7));geometry.Sphere("Hill",node,Vector3.zero,new Vector3(23,8+i%3*3,19),Color.Lerp(ground,horizon,.35f));
            }
            if(quality==3&&region!=0&&region!=2&&region!=4&&region!=5)for(int i=0;i<24;i++) { var node=geometry.Node("Flowers",terrainRoot,Vector3.zero);scenery.Add(new Scenery{Root=node,Arc=i*3-36,Z=i%2==0?2.4f:-2.4f});geometry.Cylinder("Stem",node,new Vector3(0,.15f,0),.02f,.3f,Hex("65803d"),Vector3.zero);geometry.Sphere("Flower",node,new Vector3(0,.3f,0),Vector3.one*.14f,Hex(i%2==0?"e9c45f":"d08c91")); }
            batches.Capture(transform);
        }
        void Tree(Transform node,System.Random random,bool winter)
        {
            float height=2.4f+(float)random.NextDouble()*2.8f;
            geometry.Cylinder("Trunk",node,new Vector3(0,height*.35f,0),.11f,height*.7f,Hex("64513b"),Vector3.zero);
            for(int layer=0;layer<3;layer++) { float y=height*(.42f+layer*.2f),wide=height*(.55f-layer*.12f);Color green=Hex(winter?"829787":region==6?"7f8450":"496b3d");geometry.Sphere("Canopy",node,new Vector3(0,y,0),new Vector3(wide,height*.43f,wide),green);if(winter)geometry.Sphere("Snow cap",node,new Vector3(0,y+height*.09f,0),new Vector3(wide*.93f,height*.3f,wide*.93f),Hex("d9e1d2")); }
        }
        void Building(Transform node,System.Random random)
        {
            float h=2.8f+(float)random.NextDouble()*3,w=2.2f+(float)random.NextDouble()*1.2f;Color brick=Hex(random.Next(2)==0?"af8065":"b79c7b");
            geometry.Box("Brick facade",node,new Vector3(0,h*.5f,0),new Vector3(w,h,2),brick,.12f);geometry.Box("Roof",node,new Vector3(0,h+.09f,0),new Vector3(w+.2f,.22f,2.2f),Hex("554f50"),.1f);
            for(int row=0;row<3;row++)for(int col=-1;col<=1;col++)geometry.Box("Lit window",node,new Vector3(col*w*.27f,h*(.23f+row*.26f),1.015f),new Vector3(.36f,.51f,.045f),Hex("ead099"),.035f);
        }
        void LateUpdate() { if(state==null)return;UpdateVisuals(Time.deltaTime);batches.Draw(cameraView); }
        public void UpdateVisuals(float deltaTime)
        {
            if(state==null)return;Train.Tick(deltaTime,Curved);
            foreach(var part in rail) {
                double movingArc=part.Arc+RailPath.Mod(state.Distance,.7);
                var p=RailPath.Pose(movingArc,state.Distance,Curved);var a=RailPath.Pose(movingArc-.35,state.Distance,Curved);var b=RailPath.Pose(movingArc+.35,state.Distance,Curved);
                var rotation=Quaternion.FromToRotation(Vector3.right,new Vector3((float)(b.X-a.X),0,(float)(b.Z-a.Z)));
                Vector3 pos=new Vector3((float)p.X,.1f,(float)p.Z);part.Tie.localPosition=pos;part.Tie.localRotation=rotation;
                part.Left.localPosition=pos+rotation*new Vector3(0,.055f,-.78f);part.Right.localPosition=pos+rotation*new Vector3(0,.055f,.78f);part.Left.localRotation=part.Right.localRotation=rotation;
            }
            foreach(var prop in scenery) { double arc=RailPath.Mod(prop.Arc+RailPath.Mod(state.Distance,80)+40,80)-40;var p=RailPath.Pose(arc,state.Distance,Curved);prop.Root.localPosition=new Vector3((float)p.X,0,(float)p.Z+prop.Z); }
            var engine=Train.Vehicles[0].Frame;smoke.transform.position=engine.TransformPoint(new Vector3(-1.08f,2.6f,0));snow.transform.position=Train.FocusPosition+Vector3.up*7;
            Vector3 target=Train.FocusPosition;Vector3 desired=target+new Vector3(-cameraDistance*.55f,cameraDistance*.7f,cameraDistance);
            cameraView.transform.position=Vector3.Lerp(cameraView.transform.position,desired,1-Mathf.Exp(-deltaTime*6));cameraView.transform.LookAt(target+Vector3.up*.1f);
        }
        public void Zoom(float delta) { cameraDistance=Mathf.Clamp(cameraDistance+delta,8,17); }
        public void RebuildTrain() { Train.Rebuild();batches.Capture(transform); }
        void OnDestroy() { if(geometry!=null)geometry.Dispose();if(sky)Geometry.Release(sky); }
    }
}
