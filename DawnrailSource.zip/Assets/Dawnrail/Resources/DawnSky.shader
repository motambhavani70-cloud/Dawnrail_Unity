Shader "Dawnrail/Sky" {
 Properties { _Top("Zenith",Color)=(0.3,0.4,0.5,1) _Horizon("Horizon",Color)=(0.7,0.8,0.8,1) }
 SubShader { Tags { "Queue"="Background" "RenderType"="Background" "PreviewType"="Skybox" } Cull Off ZWrite Off
  Pass { HLSLPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #include "UnityCG.cginc"
   float4 _Top, _Horizon;
   struct appdata { float4 vertex:POSITION; };
   struct v2f { float4 position:SV_POSITION;float3 ray:TEXCOORD0; };
   v2f vert(appdata v) { v2f o;o.position=UnityObjectToClipPos(v.vertex);o.ray=v.vertex.xyz;return o; }
   half4 frag(v2f i):SV_Target { float t=saturate(normalize(i.ray).y);return lerp(_Horizon,_Top,pow(t,.65)); }
  ENDHLSL }
 } Fallback Off
}
