using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Dawnrail.Core
{
    public sealed class SaveRepository
    {
        readonly string path; readonly GameContent content;
        public string Error { get; private set; }
        public SaveRepository(string directory,GameContent gameContent) { Directory.CreateDirectory(directory); path=Path.Combine(directory,"journey.json"); content=gameContent; }
        public bool Save(GameState state,double now)
        {
            try {
                string tmp=path+".tmp",json=Json.Stringify(state.Snapshot(now));
                using(var stream=new FileStream(tmp,FileMode.Create,FileAccess.Write,FileShare.None)) { byte[] bytes=Encoding.UTF8.GetBytes(json); stream.Write(bytes,0,bytes.Length); stream.Flush(true); }
                if(File.Exists(path)) {
                    // Keep an already valid backup when recovering a corrupt primary.
                    bool valid=Valid(File.ReadAllText(path));
                    try { File.Replace(tmp,path,valid?path+".bak":null); }
                    catch(PlatformNotSupportedException) { if(valid)File.Copy(path,path+".bak",true); File.Delete(path); File.Move(tmp,path); }
                } else File.Move(tmp,path);
                state.LastSeen=now; Error=""; return true;
            } catch(Exception ex) { Error=ex.GetType().Name; return false; }
        }
        bool Valid(string text) { try { return new GameState(content).Load(Json.Parse(text)); } catch { return false; } }
        public bool Load(GameState state,double now,out double offlineSeconds)
        {
            offlineSeconds=0;
            foreach(string file in new[]{path,path+".bak",path+".tmp"}) {
                try { if(!File.Exists(file)||!state.Load(Json.Parse(File.ReadAllText(file))))continue;
                    offlineSeconds=state.LastSeen>0?Math.Max(0,Math.Min(GameState.MaxOffline,now-state.LastSeen)):0;
                    state.Offline(offlineSeconds); state.LastSeen=now; Save(state,now); return true;
                } catch(Exception ex) { Error=ex.GetType().Name; }
            } return false;
        }
        public bool Import(string json,GameState state,double now)
        {
            try {
                string id; using(var sha=SHA256.Create())id=BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(json))).Replace("-","");
                string receipt=path+".import-"+id;
                if(File.Exists(receipt)) { Error="Это сохранение уже перенесено"; return false; }
                var candidate=new GameState(content); if(!candidate.Load(Json.Parse(json))) { Error="Неподдерживаемое сохранение"; return false; }
                double seconds=candidate.LastSeen>0?Math.Max(0,Math.Min(GameState.MaxOffline,now-candidate.LastSeen)):0;
                candidate.Offline(seconds); candidate.ClaimRewards();
                // Reserve before granting; a failed save removes the reservation for retry.
                File.WriteAllText(receipt,json,Encoding.UTF8);
                if(!Save(candidate,now)) { File.Delete(receipt); return false; }
                state.Load(candidate.Snapshot(now)); Error=""; return true;
            } catch(Exception ex) { Error=ex is FormatException?"Некорректный JSON":ex.GetType().Name; return false; }
        }
    }
}
