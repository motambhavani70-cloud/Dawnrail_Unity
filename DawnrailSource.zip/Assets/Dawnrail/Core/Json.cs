using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Dawnrail.Core
{
    // Independent of JsonUtility: saves contain nested maps and optional legacy fields.
    public static class Json
    {
        public static object Parse(string text) { return new Reader(text).ReadDocument(); }
        public static string Stringify(object value) { var b = new StringBuilder(); Write(b, value); return b.ToString(); }
        static void Write(StringBuilder b, object value)
        {
            if (value == null) { b.Append("null"); return; }
            if (value is string) {
                b.Append('"'); foreach (char c in (string)value) {
                    switch(c) {
                        case '"': b.Append("\\\""); break; case '\\': b.Append("\\\\"); break;
                        case '\n': b.Append("\\n"); break; case '\r': b.Append("\\r"); break; case '\t': b.Append("\\t"); break;
                        default: if(c < 32) b.Append("\\u" + ((int)c).ToString("x4")); else b.Append(c); break;
                    }
                } b.Append('"'); return;
            }
            if (value is bool) { b.Append((bool)value ? "true" : "false"); return; }
            var map = value as IDictionary;
            if(map != null) { b.Append('{'); bool first=true; foreach(DictionaryEntry entry in map) { if(!first)b.Append(','); first=false; Write(b, (string)entry.Key); b.Append(':'); Write(b,entry.Value); } b.Append('}'); return; }
            var list=value as IEnumerable;
            if(list!=null) { b.Append('['); bool first=true; foreach(object item in list) { if(!first)b.Append(','); first=false; Write(b,item); } b.Append(']'); return; }
            double number=Convert.ToDouble(value, CultureInfo.InvariantCulture);
            if(double.IsNaN(number)||double.IsInfinity(number)) throw new FormatException("Non-finite JSON number");
            b.Append(number.ToString("R",CultureInfo.InvariantCulture));
        }
        sealed class Reader
        {
            readonly string source; int position, depth;
            public Reader(string text) { if(text==null || text.Length>1048576)throw new FormatException("Invalid JSON size"); source=text; }
            void White() { while(position<source.Length && char.IsWhiteSpace(source[position]))position++; }
            char Peek() { White(); return position<source.Length?source[position]:'\0'; }
            void Expect(char c) { White(); if(position>=source.Length||source[position++]!=c)throw new FormatException("Invalid JSON syntax"); }
            public object ReadDocument() { object result=Read(); White(); if(position!=source.Length)throw new FormatException("Trailing JSON"); return result; }
            object Read()
            {
                if(++depth>32)throw new FormatException("JSON depth limit"); object result; char c=Peek();
                if(c=='{') { var map=new Dictionary<string,object>(); Expect('{'); if(Peek()!='}') do { string key=String(); Expect(':'); if(map.ContainsKey(key))throw new FormatException("Duplicate JSON key"); map.Add(key,Read()); if(Peek()!=',')break; Expect(','); } while(true); Expect('}'); result=map; }
                else if(c=='[') { var list=new List<object>(); Expect('['); if(Peek()!=']') do { list.Add(Read()); if(Peek()!=',')break; Expect(','); } while(true); Expect(']'); result=list; }
                else if(c=='"')result=String();
                else if(c=='t') { Literal("true"); result=true; }
                else if(c=='f') { Literal("false"); result=false; }
                else if(c=='n') { Literal("null"); result=null; }
                else result=Number(); --depth; return result;
            }
            void Literal(string word) { if(position+word.Length>source.Length||source.Substring(position,word.Length)!=word)throw new FormatException("Invalid JSON literal"); position+=word.Length; }
            string String()
            {
                Expect('"'); var b=new StringBuilder();
                while(position<source.Length) { char c=source[position++]; if(c=='"')return b.ToString(); if(c<32)throw new FormatException("Control character in JSON");
                    if(c=='\\') { if(position>=source.Length)throw new FormatException("JSON escape"); c=source[position++];
                        switch(c) { case '"': case '/': case '\\': b.Append(c); break; case 'b': b.Append('\b'); break; case 'f': b.Append('\f'); break; case 'n': b.Append('\n'); break; case 'r': b.Append('\r'); break; case 't': b.Append('\t'); break;
                            case 'u': if(position+4>source.Length)throw new FormatException("JSON unicode"); b.Append((char)int.Parse(source.Substring(position,4),NumberStyles.HexNumber)); position+=4; break;
                            default: throw new FormatException("JSON escape"); }
                    } else b.Append(c);
                } throw new FormatException("Unterminated JSON string");
            }
            object Number()
            {
                int start=position; if(Peek()=='-')position++;
                if(position>=source.Length)throw new FormatException("JSON number");
                if(source[position]=='0')position++; else { if(source[position]<'1'||source[position]>'9')throw new FormatException("JSON number"); while(position<source.Length&&char.IsDigit(source[position]))position++; }
                if(position<source.Length&&source[position]=='.') { position++; int digit=position; while(position<source.Length&&char.IsDigit(source[position]))position++; if(position==digit)throw new FormatException("JSON fraction"); }
                if(position<source.Length&&(source[position]=='e'||source[position]=='E')) { position++; if(position<source.Length&&(source[position]=='+'||source[position]=='-'))position++; int digit=position; while(position<source.Length&&char.IsDigit(source[position]))position++; if(position==digit)throw new FormatException("JSON exponent"); }
                double result; if(!double.TryParse(source.Substring(start,position-start),NumberStyles.Float,CultureInfo.InvariantCulture,out result)||double.IsInfinity(result)||double.IsNaN(result))throw new FormatException("JSON number range"); return result;
            }
        }
        public static Dictionary<string,object> Map(object value) { return value as Dictionary<string,object> ?? new Dictionary<string,object>(); }
        public static List<object> List(object value) { return value as List<object> ?? new List<object>(); }
        public static object Get(Dictionary<string,object> map,string key) { object v; return map.TryGetValue(key,out v)?v:null; }
        public static double Num(object value,double fallback=0,double min=0,double max=1e15) { if(!(value is double || value is int || value is long || value is float))return fallback; double d=Convert.ToDouble(value); return double.IsNaN(d)||double.IsInfinity(d)?fallback:Math.Max(min,Math.Min(max,d)); }
        public static string Str(object value,string fallback="") { return value as string ?? fallback; }
    }
}
