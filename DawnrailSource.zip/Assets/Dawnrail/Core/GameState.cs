using System;
using System.Collections.Generic;
using System.Linq;

namespace Dawnrail.Core
{
    public sealed class GameState
    {
        public const double MaxValue=1e15,MaxOffline=28800;
        public const int MaxLevel=50;
        public readonly GameContent Content;
        public double Heat,Parts=40,Distance,NextStation=180,HeatBonus,PartsBonus,LastSeen,Velocity;
        public int Engine=1,Fire=1,Crew,Taps,Station,Passengers=3,Helped,Quality=2;
        public bool Sound=true,Economy;
        public string Event="",Route="safe",LastChoice="";
        public readonly Dictionary<string,int> Wagons=new Dictionary<string,int>{{"home",1},{"workshop",0},{"garden",0}};
        public readonly Dictionary<string,int> Jobs=new Dictionary<string,int>{{"stoker",0},{"mechanic",0},{"gardener",0}};
        public readonly List<string> Rewards=new List<string>(),StoryRewards=new List<string>(),Journal=new List<string>();
        public GameState(GameContent content) { Content=content; }
        static double Cap(double v) { return Math.Max(0,Math.Min(MaxValue,v)); }
        public double TapPower { get { return 2*Math.Pow(1.22,Fire-1); } }
        public double HeatRate { get { return (.7+Crew*1.5+Wagons["garden"]*.8+Jobs["stoker"]*.6+Jobs["gardener"]*.25)*(1+(Wagons["home"]-1)*.04)*(1+HeatBonus); } }
        public double PartsRate { get { return (Wagons["workshop"]*.18+Wagons["garden"]*.06+Jobs["mechanic"]*.12+Jobs["gardener"]*.04)*(1+PartsBonus); } }
        public double Cruise { get { return (1.6+Engine*.65)*(Route=="risk"?1.2:1); } }
        public int Region { get { return Math.Min(6,Station/3); } }
        public int FreePassengers { get { return Math.Max(0,Passengers-Jobs.Values.Sum()); } }
        public double Tap() { double amount=TapPower; Heat=Cap(Heat+amount); Taps=Math.Min(1000000000,Taps+1); return amount; }
        public void Online(double seconds)
        {
            if(double.IsNaN(seconds)||double.IsInfinity(seconds)||seconds<=0)return; seconds=Math.Min(seconds,1);
            Heat=Cap(Heat+HeatRate*seconds); Parts=Cap(Parts+PartsRate*seconds);
            if(Event.Length>0) { Velocity=0; return; }
            var move=RailMotion.Travel(Velocity,Cruise,Math.Max(0,NextStation-Distance),seconds);
            Distance=Math.Min(NextStation,Distance+move.Distance); Velocity=move.Velocity; Arrive();
        }
        public void Offline(double seconds)
        {
            if(double.IsNaN(seconds)||double.IsInfinity(seconds)||seconds<=0)return; seconds=Math.Min(MaxOffline,seconds); Velocity=0;
            Heat=Cap(Heat+HeatRate*seconds); Parts=Cap(Parts+PartsRate*seconds);
            if(Event.Length==0) { Distance=Math.Min(NextStation,Distance+Cruise*seconds); Arrive(); }
        }
        void Arrive() { if(Event.Length==0&&NextStation-Distance<.00001) { Distance=NextStation; Velocity=0; string[] pool=Content.RegionEvents[Region]; Event=pool[(Station-Region*3)%pool.Length]; } }
        public int Level(string key) { if(key=="engine")return Engine; if(key=="fire")return Fire; if(key=="crew")return Crew; int v; return Wagons.TryGetValue(key,out v)?v:0; }
        public double[] Cost(string key)
        {
            int l=Level(key); double heat=MaxValue,parts=MaxValue,factor=1;
            switch(key) { case "engine":heat=55;parts=12;factor=Math.Pow(1.42,l-1);break; case "fire":heat=25;parts=0;factor=Math.Pow(1.4,l-1);break;
                case "crew":heat=70;parts=25;factor=Math.Pow(1.5,l);break; case "home":heat=90;parts=35;factor=Math.Pow(1.5,l-1);break;
                case "workshop":heat=120;parts=55;factor=Math.Pow(1.55,l);break; case "garden":heat=160;parts=75;factor=Math.Pow(1.55,l);break; }
            return new[]{Math.Ceiling(heat*factor),Math.Ceiling(parts*factor)};
        }
        public bool CanBuy(string key) { if(!(key=="engine"||key=="fire"||key=="crew"||Wagons.ContainsKey(key))||Level(key)>=MaxLevel)return false; var c=Cost(key); return Heat>=c[0]&&Parts>=c[1]; }
        public bool Buy(string key) { if(!CanBuy(key))return false; var c=Cost(key); Heat=Cap(Heat-c[0]); Parts=Cap(Parts-c[1]); if(key=="engine")Engine++; else if(key=="fire")Fire++; else if(key=="crew")Crew++; else Wagons[key]++; return true; }
        public int Capacity(string key) { if(key=="stoker")return Math.Min(8,1+Engine/3); if(key=="mechanic")return Math.Min(8,Wagons["workshop"]*2); if(key=="gardener")return Math.Min(8,Wagons["garden"]*2); return 0; }
        public bool Assign(string key,int change) { if(!Jobs.ContainsKey(key)||(change!=1&&change!=-1))return false; if(change==1&&(FreePassengers==0||Jobs[key]>=Capacity(key)))return false; if(change==-1&&Jobs[key]==0)return false; Jobs[key]+=change; return true; }
        public StationEvent CurrentEvent { get { StationEvent e; return Content.Events.TryGetValue(Event,out e)?e:null; } }
        public bool CanChoose(int index) { var e=CurrentEvent; return e!=null&&index>=0&&index<e.Choices.Length&&Heat>=e.Choices[index].HeatCost&&Parts>=e.Choices[index].PartsCost; }
        public string ChoiceNote(Choice c) { return c.Note.Replace("+5% к автотеплу",BonusNote(HeatBonus,"автотеплу","автотепла")).Replace("+5% к производству деталей",BonusNote(PartsBonus,"производству деталей","деталей")); }
        static string BonusNote(double bonus,string label,string maxLabel) { int points=(int)Math.Round(Math.Min(.05,Math.Max(0,.2-bonus))*100); return points>0?"+"+points+"% к "+label:"Бонус "+maxLabel+": макс."; }
        public bool Choose(int index)
        {
            if(!CanChoose(index))return false; var e=CurrentEvent; var c=e.Choices[index]; var f=c.Effects; string note=ChoiceNote(c);
            Heat=Cap(Heat-c.HeatCost+Json.Num(Json.Get(f,"heat"))); Parts=Cap(Parts-c.PartsCost+Json.Num(Json.Get(f,"scrap")));
            Crew=Math.Min(MaxLevel,Crew+(int)Json.Num(Json.Get(f,"crew"))); Passengers=Math.Min(100000,Passengers+(int)Json.Num(Json.Get(f,"passengers")));
            Helped=Math.Min(100000,Helped+(int)Json.Num(Json.Get(f,"help"))); HeatBonus=Math.Min(.2,HeatBonus+Json.Num(Json.Get(f,"heat_bonus"))); PartsBonus=Math.Min(.2,PartsBonus+Json.Num(Json.Get(f,"parts_bonus")));
            if(f.ContainsKey("route"))Route=Json.Str(f["route"]); LastChoice=c.Label+" · "+note; Journal.Add(e.Title+": "+c.Label); if(Journal.Count>8)Journal.RemoveAt(0);
            Station=Math.Min(100000,Station+1); NextStation=Cap(NextStation+180+Math.Min(360,Station*20)); Event=""; return true;
        }
        public bool[] StoryChecks(int chapter)
        {
            if(chapter==0)return new[]{Engine>=3,Wagons["workshop"]>=1,Wagons["garden"]>=1};
            if(chapter==1)return new[]{Wagons["home"]>=3,Station>=9,Helped>=2};
            return new[]{Engine>=6,Wagons.Values.All(v=>v>=3),Station>=18,Helped>=5};
        }
        public void ClaimRewards()
        {
            bool[] goals={Taps>=25,Engine>=3,Wagons["workshop"]>=1,Wagons["garden"]>=1,Distance>=1000,Station>=3,Station>=9,Helped>=5};
            for(int i=0;i<goals.Length;i++)if(goals[i]&&!Rewards.Contains(Content.Achievements[i])) { Rewards.Add(Content.Achievements[i]); Parts=Cap(Parts+20); }
            while(StoryRewards.Count<3&&StoryChecks(StoryRewards.Count).All(v=>v)) { int i=StoryRewards.Count; StoryRewards.Add(Content.Chapters[i]); Heat=Cap(Heat+Content.ChapterRewards[i][0]); Parts=Cap(Parts+Content.ChapterRewards[i][1]); }
        }
        public Dictionary<string,object> Snapshot(double now)
        {
            return new Dictionary<string,object>{{"version",1},{"heat",Heat},{"scrap",Parts},{"distance",Distance},{"next_station",NextStation},{"engine",Engine},{"fire",Fire},{"crew",Crew},
                {"wagons",Wagons},{"jobs",Jobs},{"taps",Taps},{"station",Station},{"event",Event},{"passengers",Passengers},{"route",Route},{"helped",Helped},{"heat_bonus",HeatBonus},{"parts_bonus",PartsBonus},
                {"rewards",Rewards},{"story_rewards",StoryRewards},{"journal",Journal},{"sound",Sound},{"economy",Economy},{"graphics_quality",Quality},{"last_seen",now}};
        }
        public bool Load(object value)
        {
            var m=value as Dictionary<string,object>; if(m==null||Json.Num(Json.Get(m,"version"))!=1)return false;
            Heat=N(m,"heat",0); Parts=N(m,"scrap",40); Distance=N(m,"distance",0); NextStation=N(m,"next_station",Distance+180,Distance);
            Engine=(int)N(m,"engine",1,1,50); Fire=(int)N(m,"fire",1,1,50); Crew=(int)N(m,"crew",0,0,50); Taps=(int)N(m,"taps",0,0,1e9); Station=(int)N(m,"station",0,0,100000);
            var w=Json.Map(Json.Get(m,"wagons")); foreach(string key in Wagons.Keys.ToArray())Wagons[key]=(int)N(w,key,key=="home"?1:0,key=="home"?1:0,50);
            Passengers=(int)N(m,"passengers",3,1,100000); Helped=(int)N(m,"helped",0,0,100000); HeatBonus=N(m,"heat_bonus",0,0,.2); PartsBonus=N(m,"parts_bonus",0,0,.2);
            string ev=Json.Str(Json.Get(m,"event")); Event=Content.Events.ContainsKey(ev)?ev:""; Route=Json.Str(Json.Get(m,"route"))=="risk"?"risk":"safe";
            Sound=Json.Get(m,"sound")==null||Equals(Json.Get(m,"sound"),true); Economy=Equals(Json.Get(m,"economy"),true); Quality=(int)N(m,"graphics_quality",2,0,3); LastSeen=N(m,"last_seen",0,0,1e12);
            Rewards.Clear(); foreach(object r in Json.List(Json.Get(m,"rewards"))) { string s=Json.Str(r); if(Content.Achievements.Contains(s)&&!Rewards.Contains(s))Rewards.Add(s); }
            StoryRewards.Clear(); var saved=Json.List(Json.Get(m,"story_rewards")); foreach(string title in Content.Chapters) { if(!saved.Contains(title))break; StoryRewards.Add(title); }
            Journal.Clear(); foreach(object item in Json.List(Json.Get(m,"journal")))if(item is string) { string s=(string)item; Journal.Add(s.Substring(0,Math.Min(280,s.Length))); if(Journal.Count>8)Journal.RemoveAt(0); }
            var jobs=Json.Map(Json.Get(m,"jobs")); int free=Passengers; foreach(string key in Jobs.Keys.ToArray()) { Jobs[key]=Math.Min(free,Math.Min(Capacity(key),(int)N(jobs,key,0,0,8))); free-=Jobs[key]; }
            Velocity=0; return true;
        }
        static double N(Dictionary<string,object> m,string key,double fallback,double min=0,double max=MaxValue) { return Json.Num(Json.Get(m,key),fallback,min,max); }
    }
}
