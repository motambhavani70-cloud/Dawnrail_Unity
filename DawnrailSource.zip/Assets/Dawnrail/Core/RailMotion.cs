using System;

namespace Dawnrail.Core
{
    public struct MotionResult { public double Distance, Velocity; public MotionResult(double distance,double velocity) { Distance=distance; Velocity=velocity; } }
    public static class RailMotion
    {
        public const double Acceleration=.9, Braking=1.6;
        public static MotionResult Travel(double velocity,double cruise,double remaining,double seconds)
        {
            double travelled=0, time=seconds;
            while(time>.000001&&remaining-travelled>.000001) {
                double dt=Math.Min(1.0/120,time),gap=Math.Max(0,remaining-travelled);
                double desired=Math.Min(cruise,Math.Sqrt(2*Braking*gap));
                double step=(desired>velocity?Acceleration:Braking)*dt;
                double next=velocity+Math.Sign(desired-velocity)*Math.Min(Math.Abs(desired-velocity),step);
                travelled+=Math.Min(gap,(velocity+next)*.5*dt); velocity=next; time-=dt;
            }
            if(remaining-travelled<.00001) { travelled=remaining; velocity=0; }
            return new MotionResult(travelled,velocity);
        }
        public static MotionResult Spring(double position,double velocity,double target,double omega,double dt)
        {
            double displacement=position-target,impulse=velocity+omega*displacement,decay=Math.Exp(-omega*dt);
            return new MotionResult(target+(displacement+impulse*dt)*decay,(velocity-omega*impulse*dt)*decay);
        }
    }
    public struct PathPoint
    {
        public double X,Z; public PathPoint(double x,double z) { X=x; Z=z; }
        public static PathPoint operator +(PathPoint a,PathPoint b) { return new PathPoint(a.X+b.X,a.Z+b.Z); }
        public static PathPoint operator -(PathPoint a,PathPoint b) { return new PathPoint(a.X-b.X,a.Z-b.Z); }
        public static PathPoint operator *(PathPoint a,double t) { return new PathPoint(a.X*t,a.Z*t); }
    }
    public static class RailPath
    {
        public const double Period=160,Step=.2;
        static readonly PathPoint[] points=Prepare();
        public static double Mod(double n,double m) { return n-Math.Floor(n/m)*m; }
        public static double Heading(double s) { double u=(Mod(s,Period)-40)/80; return u<=0||u>=1?0:.3*Math.Sin(2*Math.PI*u)*Math.Pow(Math.Sin(Math.PI*u),2); }
        static PathPoint[] Prepare() { var p=new PathPoint[801]; for(int i=0;i<800;i++) { double h=Heading((i+.5)*Step); p[i+1]=p[i]+new PathPoint(Math.Cos(h),Math.Sin(h))*Step; } return p; }
        public static PathPoint Point(double s) { double c=Mod(s,Period)/Step; int i=Math.Min(799,(int)c); return points[800]*Math.Floor(s/Period)+points[i]*(1-(c-i))+points[i+1]*(c-i); }
        public static PathPoint Pose(double arc,double distance,bool curved) { if(!curved)return new PathPoint(arc,0); double anchor=Mod(-distance,Period); return Point(anchor+arc)-Point(anchor); }
    }
}
