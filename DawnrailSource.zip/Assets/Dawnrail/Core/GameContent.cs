using System;
using System.Collections.Generic;
using System.Linq;

namespace Dawnrail.Core
{
    public sealed class Choice
    {
        public string Label, Note; public double HeatCost, PartsCost;
        public Dictionary<string,object> Effects;
    }
    public sealed class StationEvent { public string Id, Title, Body; public Choice[] Choices; }
    public sealed class GameContent
    {
        public string[] Regions, Chapters, Achievements;
        public string[][] RegionEvents;
        public double[][] ChapterRewards;
        public readonly Dictionary<string,StationEvent> Events=new Dictionary<string,StationEvent>();
        public GameContent(string json)
        {
            var root=Json.Map(Json.Parse(json));
            if(Json.Num(Json.Get(root,"schema"))!=1)throw new FormatException("Unsupported content version");
            Regions=Strings(Json.Get(root,"regions")); Chapters=Strings(Json.Get(root,"chapters")); Achievements=Strings(Json.Get(root,"achievement_names"));
            RegionEvents=Json.List(Json.Get(root,"region_events")).Select(Strings).ToArray();
            ChapterRewards=Json.List(Json.Get(root,"chapter_rewards")).Select(x=>Json.List(x).Select(v=>Json.Num(v)).ToArray()).ToArray();
            foreach(var item in Json.Map(Json.Get(root,"events"))) {
                var data=Json.Map(item.Value); var e=new StationEvent { Id=item.Key,Title=Json.Str(Json.Get(data,"title")),Body=Json.Str(Json.Get(data,"body")) };
                e.Choices=Json.List(Json.Get(data,"choices")).Select(v=> {
                    var c=Json.Map(v); var cost=Json.List(Json.Get(c,"cost"));
                    return new Choice { Label=Json.Str(Json.Get(c,"label")), Note=Json.Str(Json.Get(c,"note")), HeatCost=cost.Count>0?Json.Num(cost[0]):0, PartsCost=cost.Count>1?Json.Num(cost[1]):0, Effects=Json.Map(Json.Get(c,"effects")) };
                }).ToArray(); Events.Add(item.Key,e);
            }
            if(Regions.Length!=7||Chapters.Length!=3||Achievements.Length!=8||RegionEvents.Length!=7||ChapterRewards.Length!=3)throw new FormatException("Incomplete content");
            foreach(var pool in RegionEvents)if(pool.Length==0||pool.Any(id=>!Events.ContainsKey(id)))throw new FormatException("Invalid event pool");
            if(Events.Values.Any(e=>e.Choices.Length!=2)||ChapterRewards.Any(r=>r.Length!=2))throw new FormatException("Invalid rewards or choices");
        }
        static string[] Strings(object value) { return Json.List(value).Select(v=>Json.Str(v)).ToArray(); }
    }
}
