using System.IO;
using Dawnrail.Verification;
using Dawnrail.Unity;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.Rendering;

namespace Dawnrail.Tests
{
    public sealed class CoreTests
    {
        [Test] public void EconomySavesMotionAndGodotParity()
        {
            int count=VerificationSuite.Run(Path.GetDirectoryName(Application.dataPath));Assert.Greater(count,10000);
        }
        [Test] public void QualityAssetsArePresentAndDistinct()
        {
            RenderPipelineAsset previous=null;for(int i=0;i<4;i++) { var asset=Resources.Load<RenderPipelineAsset>("Quality/"+i);Assert.NotNull(asset,"Run Dawnrail > Prepare project first");Assert.AreNotSame(previous,asset);previous=asset; }
            Assert.NotNull(Resources.Load<Shader>("DawnSky"));Assert.NotNull(Resources.Load<Material>("TrainMaterial"));Assert.NotNull(Resources.Load<Material>("SteamMaterial"));
        }
        [Test] public void RoundedGeometryHasOutwardTriangles()
        {
            var geo=new Geometry();var root=new GameObject("Geometry test");
            try { var t=geo.Box("Rounded",root.transform,Vector3.zero,new Vector3(4,.3f,2),Color.white,.14f);var mesh=t.GetComponent<MeshFilter>().sharedMesh;var vertices=mesh.vertices;var normals=mesh.normals;var triangles=mesh.triangles;
                for(int i=0;i<triangles.Length;i+=3) { int a=triangles[i],b=triangles[i+1],c=triangles[i+2];Assert.Greater(Vector3.Dot(Vector3.Cross(vertices[b]-vertices[a],vertices[c]-vertices[a]),normals[a]+normals[b]+normals[c]),0); }
            } finally { Object.DestroyImmediate(root);geo.Dispose(); }
        }
    }
}
